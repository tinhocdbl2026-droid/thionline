import React, { useState, useRef } from 'react';
import { Student, DEFAULT_STUDENTS, BALL_COLORS } from '../types';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  Check,
  RotateCcw,
  Users,
  ClipboardList,
  FileSpreadsheet,
  GraduationCap,
} from 'lucide-react';
import { playButtonClick } from '../utils/soundEffects';
import * as XLSX from 'xlsx';

interface StudentManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  onUpdateStudents: (newStudents: Student[]) => void;
  soundVolume: number;
  classNameTitle?: string;
}

export const StudentManagerModal: React.FC<StudentManagerModalProps> = ({
  isOpen,
  onClose,
  students,
  onUpdateStudents,
  soundVolume,
  classNameTitle,
}) => {
  const [activeTab, setActiveTab] = useState<'list' | 'batch' | 'excel'>('list');
  const [singleNameInput, setSingleNameInput] = useState('');
  const [batchTextInput, setBatchTextInput] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [excelStatus, setExcelStatus] = useState<string | null>(null);
  const [excelParsed, setExcelParsed] = useState<string[]>([]);
  const excelFileRef = useRef<HTMLInputElement>(null);

  // In-modal confirm states
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [confirmResetSample, setConfirmResetSample] = useState(false);

  if (!isOpen) return null;

  // Add single student
  const handleAddSingle = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = singleNameInput.trim();
    if (!trimmed) return;

    playButtonClick(soundVolume);
    const nextNumber = students.length > 0 ? Math.max(...students.map(s => s.number)) + 1 : 1;
    const newStudent: Student = {
      id: 'st_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      name: trimmed,
      number: nextNumber,
      color: BALL_COLORS[(nextNumber - 1) % BALL_COLORS.length],
      calledCount: 0,
    };

    onUpdateStudents([...students, newStudent]);
    setSingleNameInput('');
  };

  // Process batch paste (one name per line)
  const handleBatchImport = () => {
    const lines = batchTextInput
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0);

    if (lines.length === 0) return;

    playButtonClick(soundVolume);
    const startNumber = students.length > 0 ? Math.max(...students.map(s => s.number)) + 1 : 1;
    const newStudents: Student[] = lines.map((name, idx) => {
      const num = startNumber + idx;
      return {
        id: 'st_' + Date.now() + '_' + idx + '_' + Math.random().toString(36).substr(2, 4),
        name,
        number: num,
        color: BALL_COLORS[(num - 1) % BALL_COLORS.length],
        calledCount: 0,
      };
    });

    onUpdateStudents([...students, ...newStudents]);
    setBatchTextInput('');
    setActiveTab('list');
  };

  // Process Excel upload
  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as unknown[][];

        const names: string[] = [];
        data.forEach(row => {
          if (Array.isArray(row)) {
            for (const cell of row) {
              if (typeof cell === 'string') {
                const trimmed = cell.trim();
                const isHeader =
                  /^(stt|họ và tên|họ tên|tên|name|student|id|số|no\.|ghichu|note)$/i.test(trimmed);
                if (trimmed.length > 1 && !isHeader && !/^\d+$/.test(trimmed)) {
                  names.push(trimmed);
                  break;
                }
              }
            }
          }
        });

        if (names.length > 0) {
          setExcelParsed(names);
          setExcelStatus(`Đã tìm thấy ${names.length} học sinh từ file "${file.name}"`);
        } else {
          setExcelStatus('Không nhận diện được cột tên học sinh trong file. Vui lòng kiểm tra lại!');
        }
      } catch (err) {
        console.error(err);
        setExcelStatus('Lỗi khi đọc file Excel. Vui lòng chọn file .xlsx, .xls hoặc .csv!');
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleApplyExcel = () => {
    if (excelParsed.length === 0) return;
    playButtonClick(soundVolume);
    const startNumber = students.length > 0 ? Math.max(...students.map(s => s.number)) + 1 : 1;
    const newStudents: Student[] = excelParsed.map((name, idx) => {
      const num = startNumber + idx;
      return {
        id: 'st_' + Date.now() + '_' + idx + '_' + Math.random().toString(36).substr(2, 4),
        name,
        number: num,
        color: BALL_COLORS[(num - 1) % BALL_COLORS.length],
        calledCount: 0,
      };
    });

    onUpdateStudents([...students, ...newStudents]);
    setExcelParsed([]);
    setExcelStatus(null);
    if (excelFileRef.current) excelFileRef.current.value = '';
    setActiveTab('list');
  };

  // Delete student
  const handleDelete = (id: string) => {
    playButtonClick(soundVolume);
    const updated = students.filter(s => s.id !== id);
    // Renumber sequentially
    const renumbered = updated.map((s, idx) => ({
      ...s,
      number: idx + 1,
      color: BALL_COLORS[idx % BALL_COLORS.length],
    }));
    onUpdateStudents(renumbered);
  };

  // Start editing
  const handleStartEdit = (st: Student) => {
    setEditingId(st.id);
    setEditingName(st.name);
  };

  // Save edit
  const handleSaveEdit = (id: string) => {
    const trimmed = editingName.trim();
    if (!trimmed) return;
    playButtonClick(soundVolume);
    const updated = students.map(s => (s.id === id ? { ...s, name: trimmed } : s));
    onUpdateStudents(updated);
    setEditingId(null);
  };

  // Clear all
  const handleClearAll = () => {
    playButtonClick(soundVolume);
    onUpdateStudents([]);
    setConfirmClearAll(false);
  };

  // Reset to default 20 sample students
  const handleResetToDefault = () => {
    playButtonClick(soundVolume);
    const defaults: Student[] = DEFAULT_STUDENTS.map((st, idx) => ({
      id: 'st_def_' + (idx + 1),
      name: st.name,
      number: idx + 1,
      color: BALL_COLORS[idx % BALL_COLORS.length],
      calledCount: 0,
    }));
    onUpdateStudents(defaults);
    setConfirmResetSample(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-200 select-none">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-amber-50/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-xl text-slate-900">
                  Quản lý danh sách học sinh
                </h3>
                {classNameTitle && (
                  <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-200/80 px-2.5 py-0.5 rounded-lg border border-amber-300">
                    <GraduationCap className="w-3.5 h-3.5 text-amber-700" />
                    {classNameTitle}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Sĩ số: <strong className="text-amber-600">{students.length}</strong> học sinh · Dữ liệu được lưu vĩnh viễn theo lớp
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center px-6 pt-3 border-b border-slate-100 gap-2">
          <button
            onClick={() => {
              playButtonClick(soundVolume);
              setActiveTab('list');
            }}
            className={`px-4 py-2 text-sm font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'list'
                ? 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            Danh sách ({students.length})
          </button>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              setActiveTab('batch');
            }}
            className={`px-4 py-2 text-sm font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'batch'
                ? 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <ClipboardList className="w-4 h-4" />
            Dán danh sách
          </button>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              setActiveTab('excel');
            }}
            className={`px-4 py-2 text-sm font-semibold border-b-2 transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'excel'
                ? 'border-amber-500 text-amber-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            Nhập từ Excel / CSV
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'list' ? (
            <>
              {/* Quick Add Form */}
              <form onSubmit={handleAddSingle} className="flex gap-2">
                <input
                  type="text"
                  value={singleNameInput}
                  onChange={e => setSingleNameInput(e.target.value)}
                  placeholder="Nhập họ và tên học sinh mới (ví dụ: Nguyễn Hoàng Anh)..."
                  className="flex-1 px-4 py-2.5 text-sm rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                />
                <button
                  type="submit"
                  disabled={!singleNameInput.trim()}
                  className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white rounded-2xl font-semibold text-sm flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm</span>
                </button>
              </form>

              {/* Students List */}
              <div className="space-y-1.5 max-h-[360px] overflow-y-auto pr-1">
                {students.length === 0 ? (
                  <div className="py-12 text-center text-slate-400">
                    <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p className="font-medium text-sm">Danh sách học sinh lớp này đang trống.</p>
                    <p className="text-xs mt-1">
                      Hãy nhập tên ở trên, chọn &quot;Dán danh sách&quot; hoặc &quot;Nhập từ Excel&quot;.
                    </p>
                  </div>
                ) : (
                  students.map(st => (
                    <div
                      key={st.id}
                      className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 hover:border-amber-200 bg-slate-50/60 hover:bg-amber-50/40 transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        {/* Number badge */}
                        <div
                          className="w-7 h-7 rounded-lg text-white font-mono font-bold text-xs flex items-center justify-center shrink-0 shadow-2xs"
                          style={{ backgroundColor: st.color || '#F59E0B' }}
                        >
                          {st.number}
                        </div>

                        {/* Name or Edit input */}
                        {editingId === st.id ? (
                          <div className="flex items-center gap-1 flex-1">
                            <input
                              type="text"
                              value={editingName}
                              onChange={e => setEditingName(e.target.value)}
                              autoFocus
                              className="px-2 py-1 text-sm rounded-lg border border-amber-500 outline-none flex-1 bg-white font-semibold"
                            />
                            <button
                              onClick={() => handleSaveEdit(st.id)}
                              className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-md cursor-pointer"
                              title="Lưu"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="p-1.5 text-slate-400 hover:bg-slate-200 rounded-md cursor-pointer"
                              title="Hủy"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <span className="font-semibold text-slate-800 text-sm truncate">
                            {st.name}
                          </span>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1 shrink-0">
                        {editingId !== st.id && (
                          <button
                            onClick={() => handleStartEdit(st)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                            title="Sửa tên"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(st.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="Xóa"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </>
          ) : activeTab === 'batch' ? (
            /* Batch import tab */
            <div className="space-y-3">
              <label className="block text-sm font-semibold text-slate-700">
                Dán danh sách học sinh (Mỗi học sinh một dòng):
              </label>
              <textarea
                rows={9}
                value={batchTextInput}
                onChange={e => setBatchTextInput(e.target.value)}
                placeholder={`Nguyễn Văn An\nTrần Minh Anh\nLê Hoàng Bảo\nPhạm Gia Hân\nNguyễn Thành Nam`}
                className="w-full p-3.5 text-sm rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 font-sans"
              />
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  Số học sinh nhận diện: {batchTextInput.split('\n').filter(l => l.trim()).length}
                </span>
                <button
                  onClick={handleBatchImport}
                  disabled={!batchTextInput.trim()}
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-semibold text-sm shadow-xs transition-colors cursor-pointer"
                >
                  Nhập danh sách
                </button>
              </div>
            </div>
          ) : (
            /* Excel import tab */
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">
                  Chọn file bảng điểm hoặc danh sách (.xlsx, .xls, .csv):
                </label>
                <input
                  ref={excelFileRef}
                  type="file"
                  accept=".xlsx, .xls, .csv"
                  onChange={handleExcelUpload}
                  className="w-full text-xs file:mr-3 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-amber-500 file:text-white hover:file:bg-amber-600 file:cursor-pointer text-slate-600 bg-slate-50 p-2 rounded-2xl border border-slate-200 cursor-pointer"
                />
              </div>

              {excelStatus && (
                <div
                  className={`p-3 rounded-xl text-xs font-semibold ${
                    excelParsed.length > 0
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  {excelStatus}
                </div>
              )}

              {excelParsed.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-600 font-semibold">
                    <span>Xem trước ({excelParsed.length} học sinh):</span>
                    <button
                      onClick={handleApplyExcel}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Thêm {excelParsed.length} học sinh vào lớp</span>
                    </button>
                  </div>
                  <div className="max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 space-y-1">
                    {excelParsed.slice(0, 30).map((name, i) => (
                      <div key={i} className="py-0.5 px-2 bg-white rounded border border-slate-100">
                        {i + 1}. {name}
                      </div>
                    ))}
                    {excelParsed.length > 30 && (
                      <div className="text-slate-400 italic px-2">
                        ... và còn {excelParsed.length - 30} học sinh khác
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-100">
          <div className="flex items-center gap-2">
            {confirmResetSample ? (
              <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-xl border border-amber-200 text-xs">
                <span className="text-amber-800 font-bold">Khôi phục 20 em mẫu?</span>
                <button
                  onClick={handleResetToDefault}
                  className="px-2 py-0.5 rounded bg-amber-600 text-white font-bold text-xs hover:bg-amber-700 cursor-pointer"
                >
                  Có
                </button>
                <button
                  onClick={() => setConfirmResetSample(false)}
                  className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-300 cursor-pointer"
                >
                  Hủy
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmResetSample(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-amber-700 hover:bg-amber-100/60 border border-amber-200 transition-colors cursor-pointer"
                title="Nạp lại 20 học sinh mẫu ban đầu"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Nạp mẫu 20 em</span>
              </button>
            )}

            {students.length > 0 &&
              (confirmClearAll ? (
                <div className="flex items-center gap-1 bg-rose-50 px-2 py-1 rounded-xl border border-rose-200 text-xs">
                  <span className="text-rose-800 font-bold">Xóa tất cả?</span>
                  <button
                    onClick={handleClearAll}
                    className="px-2 py-0.5 rounded bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 cursor-pointer"
                  >
                    Xóa
                  </button>
                  <button
                    onClick={() => setConfirmClearAll(false)}
                    className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-300 cursor-pointer"
                  >
                    Hủy
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setConfirmClearAll(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Xóa tất cả</span>
                </button>
              ))}
          </div>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold shadow-xs transition-colors cursor-pointer"
          >
            Hoàn tất
          </button>
        </div>
      </div>
    </div>
  );
};
