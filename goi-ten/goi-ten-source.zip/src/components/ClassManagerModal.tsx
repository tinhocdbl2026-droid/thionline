import React, { useState, useRef } from 'react';
import { SchoolClass, Student, BALL_COLORS, DEFAULT_STUDENTS } from '../types';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  Check,
  RotateCcw,
  Users,
  GraduationCap,
  FileSpreadsheet,
  AlertTriangle,
  Sparkles,
  ClipboardList,
} from 'lucide-react';
import { playButtonClick } from '../utils/soundEffects';
import * as XLSX from 'xlsx';

interface ClassManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  classes: SchoolClass[];
  activeClassId: string;
  onSelectClass: (classId: string) => void;
  onAddClass: (name: string, students: Student[]) => void;
  onRenameClass: (classId: string, newName: string) => void;
  onDeleteClass: (classId: string) => void;
  onResetClassCalled: (classId: string) => void;
  onOpenStudentManagerForClass: (classId: string) => void;
  soundVolume: number;
}

export const ClassManagerModal: React.FC<ClassManagerModalProps> = ({
  isOpen,
  onClose,
  classes,
  activeClassId,
  onSelectClass,
  onAddClass,
  onRenameClass,
  onDeleteClass,
  onResetClassCalled,
  onOpenStudentManagerForClass,
  soundVolume,
}) => {
  // Add class form state
  const [newClassName, setNewClassName] = useState('');
  const [creationMode, setCreationMode] = useState<'sample' | 'paste' | 'file' | 'empty'>('paste');
  const [pasteText, setPasteText] = useState('');
  const [fileImportStatus, setFileImportStatus] = useState<string | null>(null);
  const [fileParsedStudents, setFileParsedStudents] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Edit class state
  const [editingClassId, setEditingClassId] = useState<string | null>(null);
  const [editingClassName, setEditingClassName] = useState('');

  // Delete confirmation
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle Excel/CSV file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws, { header: 1 }) as unknown[][];

        // Extract student names from columns
        const names: string[] = [];
        data.forEach((row) => {
          if (Array.isArray(row)) {
            // Find first string cell that looks like a name
            for (const cell of row) {
              if (typeof cell === 'string') {
                const trimmed = cell.trim();
                // Filter out common header words
                const isHeader =
                  /^(stt|họ và tên|họ tên|tên|name|student|id|số|no\.|ghichu|note)$/i.test(trimmed);
                if (trimmed.length > 1 && !isHeader && !/^\d+$/.test(trimmed)) {
                  names.push(trimmed);
                  break;
                }
              }
            }
          }
        });

        if (names.length > 0) {
          setFileParsedStudents(names);
          setFileImportStatus(`Đã đọc được ${names.length} học sinh từ file "${file.name}"`);
        } else {
          setFileImportStatus('Không tìm thấy danh sách tên học sinh trong file. Vui lòng kiểm tra lại!');
        }
      } catch (err) {
        console.error(err);
        setFileImportStatus('Lỗi khi đọc file. Vui lòng chọn file .xlsx, .xls hoặc .csv!');
      }
    };
    reader.readAsBinaryString(file);
  };

  // Submit new class
  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newClassName.trim();
    if (!trimmed) return;

    playButtonClick(soundVolume);

    let rawNames: string[] = [];
    if (creationMode === 'sample') {
      rawNames = DEFAULT_STUDENTS.slice(0, 20).map(s => s.name);
    } else if (creationMode === 'paste') {
      rawNames = pasteText
        .split('\n')
        .map(l => l.trim())
        .filter(l => l.length > 0);
    } else if (creationMode === 'file') {
      rawNames = fileParsedStudents;
    }

    const students: Student[] = rawNames.map((name, idx) => ({
      id: 'st_' + Date.now() + '_' + idx + '_' + Math.random().toString(36).substr(2, 4),
      name,
      number: idx + 1,
      color: BALL_COLORS[idx % BALL_COLORS.length],
      calledCount: 0,
    }));

    onAddClass(trimmed, students);

    // Reset form
    setNewClassName('');
    setPasteText('');
    setFileParsedStudents([]);
    setFileImportStatus(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Save renamed class
  const handleSaveRename = (classId: string) => {
    const trimmed = editingClassName.trim();
    if (!trimmed) return;
    playButtonClick(soundVolume);
    onRenameClass(classId, trimmed);
    setEditingClassId(null);
    setEditingClassName('');
  };

  // Confirm and delete class
  const handleConfirmDelete = (classId: string) => {
    if (classes.length <= 1) {
      alert('Không thể xóa lớp duy nhất còn lại! Bạn cần giữ ít nhất 1 lớp học.');
      setConfirmDeleteId(null);
      return;
    }
    playButtonClick(soundVolume);
    onDeleteClass(classId);
    setConfirmDeleteId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs select-none">
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-amber-300 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-amber-100 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white flex items-center justify-between shrink-0 shadow-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/40 shadow-inner">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-display font-black text-lg sm:text-xl tracking-tight leading-tight">
                QUẢN LÝ LỚP HỌC
              </h2>
              <p className="text-xs text-amber-100/90 font-medium">
                Tạo lớp mới, đổi tên, xóa lớp và quản lý danh sách học sinh riêng biệt từng lớp
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              onClose();
            }}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
            title="Đóng (Esc)"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 space-y-6">
          {/* 1. ADD NEW CLASS SECTION */}
          <section className="bg-gradient-to-br from-amber-50/80 via-orange-50/40 to-yellow-50/60 rounded-2xl border-2 border-amber-200/90 p-4 sm:p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-6 h-6 rounded-lg bg-amber-500 text-white font-black text-xs flex items-center justify-center shadow-xs">
                +
              </span>
              <h3 className="font-display font-bold text-sm sm:text-base text-amber-950 uppercase tracking-wide">
                Thêm lớp học mới
              </h3>
            </div>

            <form onSubmit={handleCreateClass} className="space-y-3.5">
              {/* Class name input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Tên lớp học <span className="text-rose-500">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newClassName}
                    onChange={e => setNewClassName(e.target.value)}
                    placeholder="Ví dụ: Lớp 3/1, Lớp 3/2, Lớp 4/1, Lớp 5A..."
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none text-sm font-semibold bg-white shadow-xs"
                    required
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Tạo lớp</span>
                  </button>
                </div>
              </div>

              {/* Initial Student Population Mode */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Danh sách học sinh ban đầu cho lớp này:
                </label>

                {/* Tabs */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mb-2.5">
                  {[
                    { id: 'paste', label: 'Dán danh sách', icon: ClipboardList },
                    { id: 'file', label: 'File Excel / CSV', icon: FileSpreadsheet },
                    { id: 'sample', label: '20 học sinh mẫu', icon: Sparkles },
                    { id: 'empty', label: 'Lớp trống (nhập sau)', icon: Users },
                  ].map(tab => {
                    const Icon = tab.icon;
                    const isActive = creationMode === tab.id;
                    return (
                      <button
                        type="button"
                        key={tab.id}
                        onClick={() => setCreationMode(tab.id as typeof creationMode)}
                        className={`py-1.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all cursor-pointer ${
                          isActive
                            ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-amber-50/60'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{tab.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Mode: Paste Text */}
                {creationMode === 'paste' && (
                  <div className="space-y-1">
                    <textarea
                      value={pasteText}
                      onChange={e => setPasteText(e.target.value)}
                      placeholder="Dán danh sách học sinh vào đây, mỗi học sinh một dòng:&#10;Nguyễn Văn An&#10;Trần Minh Anh&#10;Lê Quốc Bảo&#10;Phạm Gia Hân"
                      rows={3}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 outline-none text-xs font-medium bg-white resize-y"
                    />
                    <p className="text-[11px] text-slate-500 italic">
                      Mỗi dòng là một học sinh. Hệ thống sẽ tự động đánh số thứ tự từ 1 trở đi.
                    </p>
                  </div>
                )}

                {/* Mode: File Upload */}
                {creationMode === 'file' && (
                  <div className="space-y-2 bg-white p-3 rounded-xl border border-slate-200">
                    <div className="flex items-center gap-3">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".xlsx, .xls, .csv"
                        onChange={handleFileUpload}
                        className="text-xs file:mr-2.5 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-amber-500 file:text-white hover:file:bg-amber-600 file:cursor-pointer text-slate-600 cursor-pointer"
                      />
                    </div>
                    {fileImportStatus && (
                      <div
                        className={`text-xs p-2 rounded-lg ${
                          fileParsedStudents.length > 0
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-rose-50 text-rose-800 border border-rose-200'
                        }`}
                      >
                        {fileImportStatus}
                      </div>
                    )}
                  </div>
                )}

                {/* Mode: Sample */}
                {creationMode === 'sample' && (
                  <div className="text-xs text-slate-600 bg-white/80 p-2.5 rounded-xl border border-slate-200">
                    Lớp sẽ được tạo với <strong>20 học sinh mẫu tiểu học</strong> sẵn có. Bạn có thể sửa tên sau bất kỳ lúc nào.
                  </div>
                )}

                {/* Mode: Empty */}
                {creationMode === 'empty' && (
                  <div className="text-xs text-slate-600 bg-white/80 p-2.5 rounded-xl border border-slate-200">
                    Lớp sẽ được tạo với <strong>danh sách trống</strong>. Bạn có thể bấm nút &quot;Danh sách HS&quot; để thêm học sinh sau.
                  </div>
                )}
              </div>
            </form>
          </section>

          {/* 2. CLASS LIST SECTION */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-sm sm:text-base text-slate-800 flex items-center gap-2">
                <Users className="w-4 h-4 text-amber-600" />
                <span>Danh sách lớp học hiện tại ({classes.length} lớp)</span>
              </h3>
              <span className="text-xs text-slate-500 font-medium">
                Bấm vào &quot;Chọn lớp này&quot; để đổi lớp giảng dạy
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {classes.map(cls => {
                const isActive = cls.id === activeClassId;
                const isEditing = editingClassId === cls.id;
                const isConfirmingDelete = confirmDeleteId === cls.id;
                const studentCount = cls.students.length;
                const calledCount = (cls.calledIds || []).length;
                const progressPct =
                  studentCount > 0 ? Math.round((calledCount / studentCount) * 100) : 0;

                return (
                  <div
                    key={cls.id}
                    className={`rounded-2xl border-2 transition-all p-3.5 sm:p-4 flex flex-col justify-between gap-3 ${
                      isActive
                        ? 'bg-amber-50/70 border-amber-400 shadow-md ring-2 ring-amber-300/60'
                        : 'bg-white border-slate-200 hover:border-amber-200 hover:shadow-xs'
                    }`}
                  >
                    {/* Top Row: Class Name & Badges */}
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        {isEditing ? (
                          <div className="flex items-center gap-1.5 flex-1">
                            <input
                              type="text"
                              value={editingClassName}
                              onChange={e => setEditingClassName(e.target.value)}
                              autoFocus
                              className="px-2.5 py-1 text-sm font-bold border border-amber-500 rounded-lg outline-none flex-1 bg-white"
                            />
                            <button
                              onClick={() => handleSaveRename(cls.id)}
                              className="p-1.5 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 cursor-pointer"
                              title="Lưu tên lớp"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setEditingClassId(null)}
                              className="p-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 cursor-pointer"
                              title="Hủy"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="font-display font-black text-base sm:text-lg text-slate-800 truncate">
                              {cls.name}
                            </span>
                            <button
                              onClick={() => {
                                setEditingClassId(cls.id);
                                setEditingClassName(cls.name);
                              }}
                              className="p-1 text-slate-400 hover:text-amber-600 rounded-md hover:bg-amber-100/60 transition-colors cursor-pointer"
                              title="Đổi tên lớp"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}

                        {/* Active Badge */}
                        {isActive ? (
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-emerald-500 text-white flex items-center gap-1 shadow-2xs shrink-0">
                            <Check className="w-3 h-3 stroke-3" />
                            <span>ĐANG CHỌN</span>
                          </span>
                        ) : (
                          <button
                            onClick={() => {
                              playButtonClick(soundVolume);
                              onSelectClass(cls.id);
                            }}
                            className="px-3 py-1 rounded-xl text-xs font-bold text-amber-700 bg-amber-100 hover:bg-amber-200 border border-amber-300 transition-colors cursor-pointer shrink-0"
                          >
                            Chọn lớp này
                          </button>
                        )}
                      </div>

                      {/* Class Stats */}
                      <div className="flex items-center gap-2 flex-wrap text-xs text-slate-600 mb-2">
                        <span className="inline-flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-md font-semibold text-slate-700">
                          <Users className="w-3 h-3 text-slate-500" />
                          <strong>{studentCount}</strong> học sinh
                        </span>

                        <span className="inline-flex items-center gap-1 bg-amber-100/80 text-amber-800 px-2 py-0.5 rounded-md font-semibold">
                          Đã gọi: <strong>{calledCount}/{studentCount}</strong> ({progressPct}%)
                        </span>
                      </div>

                      {/* Mini progress bar */}
                      <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-300"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                    </div>

                    {/* Bottom Action Buttons */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 gap-1.5">
                      <div className="flex items-center gap-1.5">
                        {/* Manage students for this class */}
                        <button
                          onClick={() => {
                            playButtonClick(soundVolume);
                            onOpenStudentManagerForClass(cls.id);
                          }}
                          className="px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 transition-colors flex items-center gap-1 cursor-pointer"
                          title="Sửa danh sách học sinh của lớp này"
                        >
                          <Users className="w-3 h-3" />
                          <span>Danh sách HS</span>
                        </button>

                        {/* Reset called status for this class */}
                        {calledCount > 0 && (
                          <button
                            onClick={() => {
                              playButtonClick(soundVolume);
                              onResetClassCalled(cls.id);
                            }}
                            className="px-2 py-1 rounded-lg text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 transition-colors flex items-center gap-1 cursor-pointer"
                            title="Đặt lại lượt gọi của riêng lớp này"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Đặt lại</span>
                          </button>
                        )}
                      </div>

                      {/* Delete Class */}
                      {isConfirmingDelete ? (
                        <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-xl border border-rose-200">
                          <span className="text-[11px] font-bold text-rose-700 px-1">Xóa lớp?</span>
                          <button
                            onClick={() => handleConfirmDelete(cls.id)}
                            className="px-2 py-0.5 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 cursor-pointer"
                          >
                            Có
                          </button>
                          <button
                            onClick={() => setConfirmDeleteId(null)}
                            className="px-2 py-0.5 rounded-lg bg-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-300 cursor-pointer"
                          >
                            Không
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmDeleteId(cls.id)}
                          disabled={classes.length <= 1}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            classes.length <= 1
                              ? 'text-slate-300 cursor-not-allowed'
                              : 'text-slate-400 hover:text-rose-600 hover:bg-rose-50'
                          }`}
                          title={
                            classes.length <= 1
                              ? 'Không thể xóa lớp duy nhất còn lại'
                              : `Xóa ${cls.name}`
                          }
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Dữ liệu các lớp được lưu tự động vĩnh viễn trên máy</span>
          </div>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-sm transition-colors cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
