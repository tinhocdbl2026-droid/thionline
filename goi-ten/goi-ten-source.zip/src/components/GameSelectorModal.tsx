import React from 'react';
import { GameMode } from '../types';
import { X, Gamepad2, Sparkles, Check } from 'lucide-react';
import { playButtonClick } from '../utils/soundEffects';

export interface GameInfo {
  id: GameMode;
  label: string;
  icon: string;
  desc: string;
  badge?: string;
  buttonLabel: string;
}

export const ALL_GAMES: GameInfo[] = [
  {
    id: 'cage',
    label: 'Lồng cầu 3D',
    icon: '🎱',
    desc: 'Lồng quay xổ số 3D vật lý thật với bóng nảy và máng trượt',
    badge: 'Phổ biến',
    buttonLabel: 'QUAY LỒNG CẦU',
  },
  {
    id: 'wheel',
    label: 'Vòng quay',
    icon: '🎡',
    desc: 'Vòng quay may mắn với kim gảy cơ học tíc tắc từng nấc',
    buttonLabel: 'QUAY VÒNG QUAY',
  },
  {
    id: 'box',
    label: 'Hộp quà bí mật',
    icon: '🎁',
    desc: 'Các hộp quà 3D rực rỡ rung lắc và bật nắp phát sáng',
    buttonLabel: 'MỞ QUÀ BÍ MẬT',
  },
  {
    id: 'balloon',
    label: 'Bóng bay',
    icon: '🎈',
    desc: 'Bóng bay lơ lửng cuộn xoáy trên bầu trời',
    buttonLabel: 'THẢ BÓNG BAY',
  },
  {
    id: 'number',
    label: 'Máy chọn số',
    icon: '🎰',
    desc: 'Bảng điện tử LED chạy số và tên học sinh tốc độ cao',
    buttonLabel: 'CHẠY MÁY CHỌN SỐ',
  },
  {
    id: 'darts',
    label: 'Phi tiêu may mắn',
    icon: '🎯',
    desc: 'Ném phi tiêu trúng hồng tâm bảng điểm chọn học sinh',
    badge: 'Mới',
    buttonLabel: 'NÉM PHI TIÊU',
  },
  {
    id: 'horse_race',
    label: 'Đua ngựa',
    icon: '🐎',
    desc: 'Các chú ngựa phi nước đại đua nhau về vạch đích',
    badge: 'Mới',
    buttonLabel: 'XUẤT PHÁT ĐUA NGỰA',
  },
  {
    id: 'rocket',
    label: 'Tên lửa phóng lên',
    icon: '🚀',
    desc: 'Bệ phóng tên lửa phụt khói bay vào không gian mặt trăng',
    badge: 'Mới',
    buttonLabel: 'PHÓNG TÊN LỬA',
  },
  {
    id: 'fishing',
    label: 'Câu cá may mắn',
    icon: '🎣',
    desc: 'Thả cần câu xuống hồ hoạt hình để bắt chú cá may mắn',
    badge: 'Mới',
    buttonLabel: 'THẢ CÂU BẮT CÁ',
  },
  {
    id: 'balloon_pop',
    label: 'Bong bóng nổ',
    icon: '💥',
    desc: 'Quả bong bóng căng phồng cực đại rồi nổ tung pháo hoa',
    badge: 'Mới',
    buttonLabel: 'BẮT ĐẦU NỔ BÓNG',
  },
  {
    id: 'ufo',
    label: 'UFO bắt học sinh',
    icon: '🛸',
    desc: 'Phi thuyền vũ trụ lướt qua chiếu tia sáng xanh bắt học sinh',
    badge: 'Mới',
    buttonLabel: 'UFO TÌM HỌC SINH',
  },
  {
    id: 'car_race',
    label: 'Đua xe siêu tốc',
    icon: '🏎️',
    desc: 'Các tay đua công thức 1 tăng tốc bốc khói về đích',
    badge: 'Mới',
    buttonLabel: 'XUẤT PHÁT ĐUA XE',
  },
  {
    id: 'brick_smash',
    label: 'Đập gạch tìm tên',
    icon: '🧱',
    desc: 'Đập tan từng lớp gạch để hé lộ tấm bảng tên học sinh',
    badge: 'Mới',
    buttonLabel: 'ĐẬP GẠCH TÌM TÊN',
  },
  {
    id: 'penalty_kick',
    label: 'Sút bóng khung thành',
    icon: '⚽',
    desc: 'Cầu thủ sút phạt đền tung lưới khung thành bóng đá',
    badge: 'Mới',
    buttonLabel: 'SÚT PHẠT ĐỀN',
  },
];

interface GameSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  soundVolume: number;
}

export const GameSelectorModal: React.FC<GameSelectorModalProps> = ({
  isOpen,
  onClose,
  currentMode,
  onSelectMode,
  soundVolume,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-amber-50 to-orange-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs text-xl">
              <Gamepad2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-xl text-slate-900">
                Kho trò chơi gọi tên học sinh ({ALL_GAMES.length} trò chơi)
              </h3>
              <p className="text-xs text-slate-500">
                Chọn trò chơi yêu thích để thay đổi không khí lớp học
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              onClose();
            }}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Games Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
            {ALL_GAMES.map(game => {
              const isSelected = currentMode === game.id;

              return (
                <button
                  key={game.id}
                  onClick={() => {
                    playButtonClick(soundVolume);
                    onSelectMode(game.id);
                    onClose();
                  }}
                  className={`relative p-4 rounded-2xl border-2 text-left transition-all cursor-pointer flex flex-col justify-between group ${
                    isSelected
                      ? 'bg-amber-50/80 border-amber-500 shadow-md scale-102 ring-2 ring-amber-300'
                      : 'bg-white border-slate-200 hover:border-amber-300 hover:shadow-md hover:bg-amber-50/30'
                  }`}
                >
                  {/* Top row */}
                  <div className="flex items-center justify-between w-full mb-2">
                    <span className="text-3xl filter drop-shadow-sm group-hover:scale-110 transition-transform">
                      {game.icon}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {game.badge && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-rose-100 text-rose-700">
                          {game.badge}
                        </span>
                      )}
                      {isSelected && (
                        <span className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-xs">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Info */}
                  <div>
                    <h4 className="font-display font-bold text-base text-slate-900 group-hover:text-amber-700 transition-colors">
                      {game.label}
                    </h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                      {game.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Tất cả các trò chơi đều dùng chung danh sách và lịch sử hiện có</span>
          </div>

          <button
            onClick={() => {
              playButtonClick(soundVolume);
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
