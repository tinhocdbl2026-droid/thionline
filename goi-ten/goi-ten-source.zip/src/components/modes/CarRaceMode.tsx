import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playCarEngineSound } from '../../utils/soundEffects';

interface CarRaceProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

interface CarRunner {
  student: Student;
  lane: number;
  progress: number;
  color: string;
  speedMultiplier: number;
  enginePitch: number;
}

const CAR_PALETTES = [
  { body: '#DC2626', stripe: '#FDE047' }, // Ferrari Red & Yellow
  { body: '#2563EB', stripe: '#FFFFFF' }, // Alpine Blue & White
  { body: '#16A34A', stripe: '#86EFAC' }, // Aston Green
  { body: '#EA580C', stripe: '#FED7AA' }, // McLaren Papaya
  { body: '#9333EA', stripe: '#F5D0FE' }, // Royal Purple
  { body: '#0D9488', stripe: '#99F6E4' }, // Petronas Teal
  { body: '#E11D48', stripe: '#FECDD3' }, // Crimson Rose
  { body: '#D97706', stripe: '#FEF08A' }, // Golden Yellow
];

// High-fidelity Vector Formula 1 / Supercar SVG
const AnimatedRaceCarSVG: React.FC<{
  bodyColor: string;
  stripeColor: string;
  isDriving: boolean;
  wheelAngle: number;
}> = ({ bodyColor, stripeColor, isDriving, wheelAngle }) => {
  return (
    <div className="relative flex items-center select-none">
      <svg
        viewBox="0 0 130 55"
        className="w-20 h-10 sm:w-24 sm:h-12 overflow-visible drop-shadow-lg"
      >
        <defs>
          <linearGradient id={`carBodyGrad_${bodyColor}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1E293B" />
            <stop offset="35%" stopColor={bodyColor} />
            <stop offset="100%" stopColor={bodyColor} />
          </linearGradient>
        </defs>

        {/* Exhaust Flame & Smoke when driving */}
        {isDriving && (
          <g transform="translate(6, 32)">
            <path
              d="M0,0 Q-12,-3 -18,0 Q-12,3 0,0"
              fill="#F97316"
              className="animate-pulse"
            />
            <circle cx="-14" cy="0" r="2.5" fill="#FEF08A" />
          </g>
        )}

        {/* Rear Wing / Spoiler */}
        <rect x="12" y="16" width="4" height="18" rx="1.5" fill="#0F172A" />
        <rect x="8" y="12" width="16" height="5" rx="1.5" fill={bodyColor} stroke="#FFFFFF" strokeWidth="0.8" />

        {/* Aerodynamic Chassis Body */}
        <path
          d="M16,34 L32,32 L60,26 Q85,22 108,30 L118,34 Q122,38 116,42 L24,42 Q14,40 16,34 Z"
          fill={`url(#carBodyGrad_${bodyColor})`}
          stroke="#FFFFFF"
          strokeWidth="1.2"
        />

        {/* Racing Stripe */}
        <path
          d="M32,33 L62,28 L114,35 L112,38 L60,32 L30,36 Z"
          fill={stripeColor}
          opacity="0.9"
        />

        {/* Cockpit & Driver Helmet */}
        <ellipse cx="64" cy="24" rx="9" ry="5.5" fill="#0F172A" />
        {/* Helmet */}
        <circle cx="65" cy="21" r="5" fill="#F8FAFC" stroke="#0F172A" strokeWidth="1" />
        {/* Visor */}
        <path d="M66,20 Q69,21 68,23 L64,23 Z" fill="#38BDF8" />

        {/* Front Nose Wing */}
        <path d="M112,35 L124,37 L124,42 L112,42 Z" fill="#0F172A" />

        {/* Back Wheel (with rotating rim Spokes) */}
        <g transform="translate(32, 40)">
          <circle cx="0" cy="0" r="9" fill="#0F172A" stroke="#475569" strokeWidth="1.5" />
          <circle cx="0" cy="0" r="5.5" fill="#64748B" />
          <g transform={`rotate(${wheelAngle})`}>
            <line x1="-5.5" y1="0" x2="5.5" y2="0" stroke="#F8FAFC" strokeWidth="1.5" />
            <line x1="0" y1="-5.5" x2="0" y2="5.5" stroke="#F8FAFC" strokeWidth="1.5" />
          </g>
          <circle cx="0" cy="0" r="2.5" fill="#FEF08A" />
        </g>

        {/* Front Wheel (with rotating rim Spokes) */}
        <g transform="translate(100, 40)">
          <circle cx="0" cy="0" r="9" fill="#0F172A" stroke="#475569" strokeWidth="1.5" />
          <circle cx="0" cy="0" r="5.5" fill="#64748B" />
          <g transform={`rotate(${wheelAngle})`}>
            <line x1="-5.5" y1="0" x2="5.5" y2="0" stroke="#F8FAFC" strokeWidth="1.5" />
            <line x1="0" y1="-5.5" x2="0" y2="5.5" stroke="#F8FAFC" strokeWidth="1.5" />
          </g>
          <circle cx="0" cy="0" r="2.5" fill="#FEF08A" />
        </g>
      </svg>
    </div>
  );
};

export const CarRaceMode: React.FC<CarRaceProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [runners, setRunners] = useState<CarRunner[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const raceStartRef = useRef<number | null>(null);
  const targetWinnerRef = useRef<Student | null>(null);
  const hasFinishedRef = useRef(false);
  const lastSoundTimeRef = useRef(0);
  const wheelRotationRef = useRef(0);

  const initCars = () => {
    if (availableStudents.length === 0) return;
    const pool = [...availableStudents];
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }

    const count = Math.min(6, Math.max(3, pool.length));
    const selected = pool.slice(0, count);

    setRunners(
      selected.map((st, idx) => ({
        student: st,
        lane: idx + 1,
        progress: 0,
        color: CAR_PALETTES[idx % CAR_PALETTES.length].body,
        speedMultiplier: 0.92 + Math.random() * 0.16,
        enginePitch: 0.8 + Math.random() * 0.4,
      }))
    );
  };

  useEffect(() => {
    initCars();
  }, [availableStudents]);

  useEffect(() => {
    if (isSpinning && runners.length > 0) {
      hasFinishedRef.current = false;
      raceStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * runners.length);
      const winner = runners[winnerIdx].student;
      targetWinnerRef.current = winner;

      setRunners(prev =>
        prev.map((r, i) => ({
          ...r,
          progress: 0,
          speedMultiplier: i === winnerIdx ? 1.05 : 0.85 + Math.random() * 0.12,
        }))
      );
    }
  }, [isSpinning]);

  // High-performance 60FPS animation loop
  useEffect(() => {
    if (!isSpinning) return;

    const animateCars = (time: number) => {
      if (!raceStartRef.current || !targetWinnerRef.current) return;
      const elapsed = (time - raceStartRef.current) / 1000;
      const totalDur = Math.max(1.5, duration);

      wheelRotationRef.current += 30;

      if (soundEnabled && time - lastSoundTimeRef.current > 180) {
        playCarEngineSound(soundVolume * 0.45);
        lastSoundTimeRef.current = time;
      }

      // Smooth custom acceleration curve (ease-in-out quintic progress)
      const tNorm = Math.min(1, elapsed / totalDur);
      const progressFactor = tNorm < 0.5 ? 4 * tNorm * tNorm * tNorm : 1 - Math.pow(-2 * tNorm + 2, 3) / 2;
      const baseProgress = progressFactor * 100;

      setRunners(prev =>
        prev.map(r => {
          const isWinner = r.student.id === targetWinnerRef.current?.id;
          const drift = Math.sin(time * 0.007 + r.lane * 1.8) * 3.5;
          const targetProg = isWinner ? 100 : 93;
          const prog = Math.min(targetProg, baseProgress * r.speedMultiplier + drift);

          return {
            ...r,
            progress: Math.max(0, prog),
          };
        })
      );

      if (elapsed >= totalDur && !hasFinishedRef.current) {
        hasFinishedRef.current = true;
        setRunners(prev =>
          prev.map(r => ({
            ...r,
            progress: r.student.id === targetWinnerRef.current?.id ? 100 : r.progress,
          }))
        );

        setTimeout(() => {
          if (targetWinnerRef.current) {
            onSpinEnd(targetWinnerRef.current);
          }
        }, 500);
      } else {
        animFrameRef.current = requestAnimationFrame(animateCars);
      }
    };

    animFrameRef.current = requestAnimationFrame(animateCars);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Asphalt Grand Prix Arena - MAXIMUM HORIZONTAL EXPANSION */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 rounded-3xl p-3 sm:p-4 shadow-2xl border-4 border-yellow-400 relative overflow-hidden flex flex-col justify-between">
        {/* Track header */}
        <div className="flex items-center justify-between px-3 py-1.5 mb-2 text-white text-xs font-bold uppercase tracking-wider shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 animate-ping" />
            <span className="font-display tracking-widest text-yellow-300 text-sm sm:text-base font-black">ĐƯỜNG ĐUA F1 SIÊU TỐC</span>
          </div>

          <button
            onClick={() => {
              if (!isSpinning) initCars();
            }}
            disabled={isSpinning}
            className="text-yellow-300 hover:text-white underline text-xs font-bold cursor-pointer transition-colors"
          >
            Đổi các tay đua
          </button>
        </div>

        {/* Lanes - FULL HORIZONTAL WIDTH */}
        <div className="space-y-1.5 sm:space-y-2 relative bg-slate-950 p-2 sm:p-2.5 rounded-2xl border border-slate-700 shadow-inner overflow-hidden flex-1 overflow-y-auto min-h-0">
          {/* Finish Line Checkered Banner */}
          <div className="absolute right-16 top-0 bottom-0 w-4 z-20 pointer-events-none opacity-90 shadow-md">
            <div className="w-full h-full bg-[linear-gradient(45deg,#fff_25%,#000_25%,#000_50%,#fff_50%,#fff_75%,#000_75%,#000_100%)] bg-[length:12px_12px]" />
            <div className="absolute -top-1 -left-2 text-[10px] font-black text-yellow-400 uppercase tracking-tighter bg-slate-900 px-1 rounded-xs">
              ĐÍCH
            </div>
          </div>

          {runners.map(r => {
            const isWinnerCrossing = hasFinishedRef.current && r.student.id === targetWinnerRef.current?.id;
            const carPalette = CAR_PALETTES[(r.lane - 1) % CAR_PALETTES.length];

            return (
              <div
                key={r.student.id}
                className="relative h-12 sm:h-14 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 rounded-xl border border-slate-700/80 flex items-center overflow-hidden shadow-xs"
              >
                {/* Lane number */}
                <div className="absolute left-2.5 z-10 w-7 h-7 rounded-full bg-yellow-400 text-slate-950 font-mono font-black text-xs sm:text-sm flex items-center justify-center shadow-md">
                  {r.lane}
                </div>

                {/* Animated Race Car & Name */}
                <div
                  className="absolute flex items-center gap-2 will-change-transform z-30 transition-transform duration-75 ease-out"
                  style={{
                    transform: `translate3d(calc(36px + (100% - 170px) * ${r.progress / 100}), 0, 0)`,
                  }}
                >
                  {/* High Quality Formula 1 Car SVG */}
                  <AnimatedRaceCarSVG
                    bodyColor={carPalette.body}
                    stripeColor={carPalette.stripe}
                    isDriving={isSpinning}
                    wheelAngle={wheelRotationRef.current}
                  />

                  {/* Name Badge - BIGGER TEXT */}
                  <div
                    className={`px-3 py-1.5 rounded-xl shadow-md border text-xs sm:text-base font-extrabold truncate max-w-[140px] sm:max-w-[200px] transition-all ${
                      isWinnerCrossing
                        ? 'bg-yellow-300 text-slate-950 border-yellow-100 scale-110 font-black shadow-lg animate-bounce'
                        : 'bg-white/95 text-slate-800 border-slate-200'
                    }`}
                  >
                    {r.student.name}
                  </div>
                </div>

                {/* White Dashed Track Lines */}
                <div className="w-full border-t border-dashed border-white/20 absolute top-1/2 pointer-events-none" />
              </div>
            );
          })}
        </div>

        {/* Bottom subtle label */}
        <div className="text-center mt-1.5 text-yellow-300/80 text-xs font-semibold shrink-0">
          🏎️ Đua xe siêu tốc 60 FPS · Đường đua mở rộng toàn màn hình
        </div>
      </div>
    </div>
  );
};
