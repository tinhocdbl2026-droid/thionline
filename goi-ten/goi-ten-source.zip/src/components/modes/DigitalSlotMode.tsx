import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playWheelTick, playBallBounceSound } from '../../utils/soundEffects';

interface DigitalSlotProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

export const DigitalSlotMode: React.FC<DigitalSlotProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [displayNumber, setDisplayNumber] = useState<number>(availableStudents[0]?.number || 1);
  const [displayName, setDisplayName] = useState<string>(availableStudents[0]?.name || '---');
  const [isLocked, setIsLocked] = useState(false);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isSpinning && availableStudents.length > 0) {
      setIsLocked(false);
      const winner = availableStudents[Math.floor(Math.random() * availableStudents.length)];
      const startTime = performance.now();
      const totalMs = duration * 1000;

      let delay = 40; // very fast roll

      const runRoll = () => {
        const elapsed = performance.now() - startTime;
        const randomStudent = availableStudents[Math.floor(Math.random() * availableStudents.length)];
        setDisplayNumber(randomStudent.number);
        setDisplayName(randomStudent.name);

        if (soundEnabled && Math.random() > 0.5) {
          playWheelTick(soundVolume * 0.3);
        }

        if (elapsed < totalMs - 1200) {
          timerRef.current = window.setTimeout(runRoll, delay);
        } else if (elapsed < totalMs) {
          // Tension slowdown
          delay += 45;
          timerRef.current = window.setTimeout(runRoll, delay);
        } else {
          // Lock on winner
          setDisplayNumber(winner.number);
          setDisplayName(winner.name);
          setIsLocked(true);

          if (soundEnabled) {
            playBallBounceSound(soundVolume * 0.8);
          }

          setTimeout(() => {
            onSpinEnd(winner);
          }, 700);
        }
      };

      runRoll();

      return () => {
        if (timerRef.current) clearTimeout(timerRef.current);
      };
    }
  }, [isSpinning, availableStudents, duration, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none max-w-4xl px-2 overflow-hidden">
      {/* Arcade / Digital Lottery Board - MAXIMUM EXPANSION */}
      <div className="relative w-full bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 p-4 sm:p-6 rounded-3xl shadow-2xl border-4 border-amber-300 max-h-[calc(100vh-115px)] flex flex-col justify-between">
        {/* Flashing Marquee Bulbs */}
        <div className="absolute top-2.5 left-6 right-6 flex justify-between">
          {[...Array(13)].map((_, i) => (
            <div
              key={i}
              className={`w-3.5 h-3.5 rounded-full ${
                isSpinning
                  ? i % 2 === 0
                    ? 'bg-yellow-200 shadow-md shadow-yellow-200 animate-ping'
                    : 'bg-red-400'
                  : 'bg-yellow-300 shadow-xs'
              }`}
            />
          ))}
        </div>

        {/* Machine Header */}
        <div className="text-center pt-2 pb-1.5 shrink-0">
          <span className="text-white font-display text-lg sm:text-2xl tracking-wider uppercase font-black drop-shadow">
            MÁY CHỌN SỐ ĐIỆN TỬ
          </span>
        </div>

        {/* Big LED Number Display Window */}
        <div className="bg-slate-950 rounded-3xl p-5 sm:p-7 border-4 border-amber-400 shadow-inner flex flex-col items-center justify-center relative overflow-hidden flex-1">
          {/* Subtle grid lines background */}
          <div
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)',
              backgroundSize: '16px 16px',
            }}
          />

          {/* Number Label */}
          <span className="text-amber-400/90 text-xs sm:text-sm font-black uppercase tracking-widest mb-1">
            SỐ THỨ TỰ HỌC SINH
          </span>

          {/* Big Number Roll - MASSIVE FOR PROJECTION */}
          <div
            className={`font-mono tabular-nums text-8xl sm:text-9xl md:text-[10rem] leading-none font-black transition-all ${
              isLocked
                ? 'text-yellow-400 scale-110 drop-shadow-[0_0_40px_rgba(250,204,21,0.9)]'
                : 'text-amber-300'
            }`}
          >
            {String(displayNumber).padStart(2, '0')}
          </div>

          {/* Rapid Name Display Banner */}
          <div className="mt-4 w-full bg-slate-900/95 rounded-2xl px-5 py-3 border border-slate-700/80 text-center shadow-md">
            <span className="text-xs text-slate-400 block mb-0.5 font-bold">Học sinh tương ứng:</span>
            <span
              className={`font-display text-3xl sm:text-5xl font-black truncate block ${
                isLocked ? 'text-emerald-400 scale-103' : 'text-slate-100'
              }`}
            >
              {displayName}
            </span>
          </div>
        </div>

        {/* Bottom Decorative Bulbs */}
        <div className="mt-2.5 flex justify-between px-6 shrink-0">
          {[...Array(13)].map((_, i) => (
            <div
              key={i}
              className={`w-3.5 h-3.5 rounded-full ${
                isSpinning
                  ? i % 2 !== 0
                    ? 'bg-yellow-200 shadow-md shadow-yellow-200 animate-pulse'
                    : 'bg-amber-300'
                  : 'bg-yellow-300 shadow-xs'
              }`}
            />
          ))}
        </div>
      </div>

      <div className="text-center mt-1 text-slate-500 text-xs font-semibold">
        Máy chọn số điện tử · Chạy số ngẫu nhiên tốc độ cao
      </div>
    </div>
  );
};
