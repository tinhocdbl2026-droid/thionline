import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playBoxOpen, playBallBounceSound } from '../../utils/soundEffects';

interface MysteryBoxProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

const BOX_COLORS = [
  { box: 'from-amber-400 to-amber-600', ribbon: 'bg-red-500', shadow: 'shadow-amber-500/20' },
  { box: 'from-rose-400 to-rose-600', ribbon: 'bg-amber-300', shadow: 'shadow-rose-500/20' },
  { box: 'from-sky-400 to-sky-600', ribbon: 'bg-yellow-300', shadow: 'shadow-sky-500/20' },
  { box: 'from-emerald-400 to-emerald-600', ribbon: 'bg-rose-400', shadow: 'shadow-emerald-500/20' },
  { box: 'from-purple-400 to-purple-600', ribbon: 'bg-amber-300', shadow: 'shadow-purple-500/20' },
  { box: 'from-indigo-400 to-indigo-600', ribbon: 'bg-emerald-300', shadow: 'shadow-indigo-500/20' },
  { box: 'from-pink-400 to-pink-600', ribbon: 'bg-sky-300', shadow: 'shadow-pink-500/20' },
  { box: 'from-teal-400 to-teal-600', ribbon: 'bg-amber-400', shadow: 'shadow-teal-500/20' },
];

export const MysteryBoxMode: React.FC<MysteryBoxProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [highlightedIndex, setHighlightedIndex] = useState<number | null>(null);
  const [openedBoxIndex, setOpenedBoxIndex] = useState<number | null>(null);
  const [chosenStudent, setChosenStudent] = useState<Student | null>(null);
  const spinTimerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isSpinning && availableStudents.length > 0) {
      setOpenedBoxIndex(null);
      setChosenStudent(null);

      const winnerIdx = Math.floor(Math.random() * availableStudents.length);
      const winner = availableStudents[winnerIdx];
      setChosenStudent(winner);

      const startTime = performance.now();
      const totalMs = duration * 1000;

      let interval = 80;
      let currentIndex = 0;

      const cycleBoxes = () => {
        const elapsed = performance.now() - startTime;
        currentIndex = (currentIndex + 1) % availableStudents.length;
        setHighlightedIndex(currentIndex);

        if (soundEnabled && Math.random() > 0.4) {
          playBallBounceSound(soundVolume * 0.2);
        }

        if (elapsed < totalMs - 800) {
          // Accelerate or stay fast
          spinTimerRef.current = window.setTimeout(cycleBoxes, interval);
        } else if (elapsed < totalMs) {
          // Slow down before stopping on winner
          interval += 60;
          spinTimerRef.current = window.setTimeout(cycleBoxes, interval);
        } else {
          // Lock on winner!
          setHighlightedIndex(winnerIdx);
          setOpenedBoxIndex(winnerIdx);

          if (soundEnabled) {
            playBoxOpen(soundVolume);
          }

          setTimeout(() => {
            onSpinEnd(winner);
          }, 900);
        }
      };

      cycleBoxes();

      return () => {
        if (spinTimerRef.current) clearTimeout(spinTimerRef.current);
      };
    }
  }, [isSpinning, availableStudents, duration, soundEnabled, soundVolume, onSpinEnd]);

  // Click on a specific box directly if not currently spinning
  const handleBoxClick = (idx: number) => {
    if (isSpinning) return;
    const student = availableStudents[idx];
    if (!student) return;

    setHighlightedIndex(idx);
    setOpenedBoxIndex(idx);
    setChosenStudent(student);

    if (soundEnabled) {
      playBoxOpen(soundVolume);
    }

    setTimeout(() => {
      onSpinEnd(student);
    }, 700);
  };

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Interactive Grid of Gift Boxes - FULL EXPANSION */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] overflow-y-auto px-2 py-3 flex flex-col justify-between">
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-6 gap-3.5 sm:gap-5 justify-items-center flex-1 items-center">
          {availableStudents.map((st, i) => {
            const isHighlighted = highlightedIndex === i;
            const isOpened = openedBoxIndex === i;
            const colorSet = BOX_COLORS[i % BOX_COLORS.length];

            return (
              <button
                key={st.id}
                onClick={() => handleBoxClick(i)}
                disabled={isSpinning}
                className={`group relative flex flex-col items-center transition-all duration-200 cursor-pointer ${
                  isHighlighted ? 'scale-115 -translate-y-2 z-20' : 'hover:scale-105 hover:-translate-y-1'
                } ${isOpened ? 'animate-bounce' : ''}`}
              >
                {/* 3D Box Body */}
                <div
                  className={`relative w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-2xl bg-gradient-to-br ${colorSet.box} shadow-xl ${colorSet.shadow} border-2 border-white/70 flex items-center justify-center overflow-hidden transition-transform`}
                >
                  {/* Ribbon cross */}
                  <div className={`absolute w-full h-3.5 sm:h-4 ${colorSet.ribbon} top-1/2 -translate-y-1/2 shadow-xs`} />
                  <div className={`absolute h-full w-3.5 sm:h-4 ${colorSet.ribbon} left-1/2 -translate-x-1/2 shadow-xs`} />

                  {/* Ribbon Bow on Top */}
                  <div className="absolute top-1.5 flex items-center justify-center z-10">
                    <span className="text-base sm:text-lg">🎀</span>
                  </div>

                  {/* Number Badge */}
                  <div className="relative z-10 w-9 h-9 sm:w-11 sm:h-11 rounded-full bg-white text-slate-900 font-mono font-black text-base sm:text-xl flex items-center justify-center shadow-md border-2 border-amber-300">
                    {st.number}
                  </div>

                  {/* Open Lid Effect */}
                  {isOpened && (
                    <div className="absolute inset-0 bg-yellow-300/85 backdrop-blur-xs flex items-center justify-center animate-ping text-2xl">
                      ✨
                    </div>
                  )}
                </div>

                {/* Box Title / Preview */}
                <span className="mt-1 text-xs sm:text-sm font-extrabold text-slate-700 truncate max-w-[90px]">
                  Hộp {st.number}
                </span>
              </button>
            );
          })}
        </div>

        <div className="text-center mt-2 text-slate-500 text-xs font-semibold shrink-0">
          {isSpinning
            ? '🎁 Đang xáo trộn các hộp bí mật...'
            : '🎁 Bấm trực tiếp vào hộp quà hoặc nhấn "Chọn ngay" để mở hộp!'}
        </div>
      </div>
    </div>
  );
};
