import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playSoccerKickSound, playVictoryFanfare } from '../../utils/soundEffects';

interface PenaltyKickProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

// Vector Football Player SVG winding up to kick
const SoccerPlayerSVG: React.FC<{ isKicking: boolean }> = ({ isKicking }) => {
  return (
    <svg viewBox="0 0 100 100" className="w-16 h-16 sm:w-20 sm:h-20 drop-shadow-lg select-none">
      {/* Player Head & Hair */}
      <circle cx="50" cy="22" r="9" fill="#FDE047" stroke="#0F172A" strokeWidth="1.5" />
      <circle cx="50" cy="23" r="8" fill="#FDBA74" />
      {/* Eye & Smile */}
      <circle cx="54" cy="22" r="1.2" fill="#0F172A" />

      {/* Athletic Jersey Shirt */}
      <path d="M38,34 L62,34 L58,56 L42,56 Z" fill="#DC2626" stroke="#FFFFFF" strokeWidth="1.2" />
      {/* Jersey Number */}
      <text x="50" y="48" fontSize="10" fontWeight="900" fill="#FFFFFF" textAnchor="middle">10</text>

      {/* Arms */}
      <path d="M38,36 L24,44" stroke="#DC2626" strokeWidth="4" strokeLinecap="round" />
      <path d="M62,36 L76,30" stroke="#DC2626" strokeWidth="4" strokeLinecap="round" />

      {/* Left Standing Leg */}
      <path d="M44,56 L40,78 L34,80" stroke="#0F172A" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />

      {/* Right Kicking Leg (Animates on kick) */}
      <g transform={isKicking ? 'rotate(35, 56, 56)' : 'rotate(-25, 56, 56)'} className="transition-transform duration-150">
        <path d="M56,56 L64,74 L74,74" stroke="#0F172A" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
        {/* Cleat boot */}
        <ellipse cx="74" cy="74" rx="4" ry="2.5" fill="#EF4444" />
      </g>
    </svg>
  );
};

export const PenaltyKickMode: React.FC<PenaltyKickProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [targetWinner, setTargetWinner] = useState<Student | null>(null);
  const [ballProgress, setBallProgress] = useState(0);
  const [isGoal, setIsGoal] = useState(false);
  const animFrameRef = useRef<number | null>(null);
  const kickStartRef = useRef<number | null>(null);
  const hasKickedRef = useRef(false);

  // 6 Target pockets in the goal
  const [goalTargets, setGoalTargets] = useState<Student[]>([]);

  const initTargets = () => {
    if (availableStudents.length === 0) return;
    const pool = [...availableStudents];
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    const count = Math.min(6, Math.max(3, pool.length));
    setGoalTargets(pool.slice(0, count));
  };

  useEffect(() => {
    initTargets();
  }, [availableStudents]);

  useEffect(() => {
    if (isSpinning && goalTargets.length > 0) {
      setBallProgress(0);
      setIsGoal(false);
      hasKickedRef.current = false;
      kickStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * goalTargets.length);
      const winner = goalTargets[winnerIdx];
      setTargetWinner(winner);

      if (soundEnabled) {
        playSoccerKickSound(soundVolume);
      }
    }
  }, [isSpinning, goalTargets]);

  // High-performance 60FPS parabolic ball trajectory
  useEffect(() => {
    if (!isSpinning) return;

    const animateKick = (time: number) => {
      if (!kickStartRef.current || !targetWinner) return;
      const elapsed = (time - kickStartRef.current) / 1000;
      const totalDur = Math.max(1.5, duration);

      if (elapsed < totalDur * 0.72) {
        const prog = elapsed / (totalDur * 0.72);
        // Ease-in accelerated parabolic flight
        setBallProgress(Math.pow(prog, 2.2));
      } else if (!hasKickedRef.current) {
        hasKickedRef.current = true;
        setBallProgress(1);
        setIsGoal(true);

        if (soundEnabled) {
          playVictoryFanfare(soundVolume * 0.7);
        }

        setTimeout(() => {
          onSpinEnd(targetWinner);
        }, 750);
      }

      animFrameRef.current = requestAnimationFrame(animateKick);
    };

    animFrameRef.current = requestAnimationFrame(animateKick);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, targetWinner, soundEnabled, soundVolume, onSpinEnd]);

  // Target spot coordinates in goal
  const winnerIndex = goalTargets.findIndex(t => t.id === targetWinner?.id);
  const targetCol = winnerIndex >= 0 ? winnerIndex % 3 : 1;
  const targetRow = winnerIndex >= 0 ? Math.floor(winnerIndex / 3) : 0;

  const targetXPercent = 20 + targetCol * 30; // 20%, 50%, 80%
  const targetYPercent = 18 + targetRow * 24; // 18%, 42%

  const currentBallX = 50 + (targetXPercent - 50) * ballProgress;
  const currentBallY = 85 - (85 - targetYPercent) * ballProgress;
  const ballScale = 1.3 - 0.7 * ballProgress; // Shrinks as it curves away into net

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none max-w-5xl px-1 sm:px-2 overflow-hidden">
      {/* Stadium Pitch */}
      <div className="w-full bg-gradient-to-b from-emerald-600 via-emerald-700 to-green-900 rounded-3xl p-4 sm:p-5 shadow-2xl border-4 border-emerald-400 relative overflow-hidden h-[min(88%,calc(100vh-130px))] min-h-[380px] flex flex-col justify-between">
        {/* Pitch grass stripes background */}
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,rgba(0,0,0,0.06)_0px,rgba(0,0,0,0.06)_40px,transparent_40px,transparent_80px)] pointer-events-none" />

        {/* Goal Net at Top */}
        <div className="relative z-10 w-full max-w-2xl mx-auto h-48 sm:h-52 bg-white/20 backdrop-blur-xs rounded-t-2xl border-4 border-white shadow-2xl flex flex-col justify-between p-2">
          {/* Net Grid overlay */}
          <div
            className="absolute inset-0 opacity-45 pointer-events-none"
            style={{
              backgroundImage: 'linear-gradient(#fff 1.5px, transparent 1.5px), linear-gradient(90deg, #fff 1.5px, transparent 1.5px)',
              backgroundSize: '15px 15px',
            }}
          />

          {/* Goal Target Pockets inside Net */}
          <div className="relative z-10 grid grid-cols-3 grid-rows-2 gap-2 sm:gap-3 h-full">
            {goalTargets.map((st) => {
              const isHit = isGoal && targetWinner?.id === st.id;

              return (
                <div
                  key={st.id}
                  className={`rounded-xl border-2 flex flex-col items-center justify-center p-1.5 transition-all ${
                    isHit
                      ? 'bg-yellow-400 border-white scale-106 shadow-xl ring-2 ring-yellow-200'
                      : 'bg-slate-900/65 border-white/60 hover:bg-slate-900/80 shadow-sm'
                  }`}
                >
                  <span
                    className={`font-mono font-black ${
                      isHit ? 'text-slate-950 text-xs sm:text-sm font-black' : 'text-yellow-300 text-[11px] sm:text-xs'
                    }`}
                  >
                    Số {st.number}
                  </span>
                  <span
                    className={`text-xs sm:text-sm font-bold truncate max-w-full text-center ${
                      isHit ? 'text-slate-950 font-black' : 'text-white'
                    }`}
                  >
                    {st.name}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3D Flying Soccer Ball with Spin */}
        <div
          className="absolute z-30 pointer-events-none flex items-center justify-center will-change-transform"
          style={{
            left: `${currentBallX}%`,
            top: `${currentBallY}%`,
            transform: `translate(-50%, -50%) scale(${ballScale}) rotate(${ballProgress * 900}deg)`,
          }}
        >
          <svg viewBox="0 0 40 40" className="w-10 h-10 drop-shadow-xl overflow-visible">
            <circle cx="20" cy="20" r="18" fill="#FFFFFF" stroke="#0F172A" strokeWidth="1.5" />
            <polygon points="20,10 27,15 25,23 15,23 13,15" fill="#0F172A" />
            <polygon points="8,10 13,15 11,21 5,21 3,14" fill="#0F172A" />
            <polygon points="32,10 37,14 35,21 29,21 27,15" fill="#0F172A" />
            <polygon points="20,32 15,26 18,21 22,21 25,26" fill="#0F172A" />
          </svg>
        </div>

        {/* Penalty Spot & Player on pitch */}
        <div className="relative z-10 flex items-center justify-between px-6 pb-2">
          {/* Animated Football Player */}
          <div className="flex items-center gap-2">
            <SoccerPlayerSVG isKicking={isSpinning} />
            <div className="bg-slate-900/80 px-2.5 py-1 rounded-xl text-xs font-bold text-white border border-slate-700">
              Cầu thủ sút phạt đền
            </div>
          </div>

          {/* Goal status banner */}
          {isGoal && (
            <div className="bg-yellow-400 text-slate-950 font-display font-black text-xl px-5 py-1.5 rounded-full shadow-2xl border-2 border-white animate-bounce">
              VÀO RỒI! ⚽🎉
            </div>
          )}

          <button
            onClick={() => {
              if (!isSpinning) initTargets();
            }}
            disabled={isSpinning}
            className="text-xs font-semibold text-emerald-100 hover:text-white underline cursor-pointer transition-colors"
          >
            Đổi các góc sút
          </button>
        </div>
      </div>

      <div className="text-center mt-3 text-slate-500 text-xs sm:text-sm font-medium">
        Sút bóng vào khung thành 60 FPS · Quả bóng bay xoáy vào ô của bạn nào sẽ gọi bạn đó!
      </div>
    </div>
  );
};
