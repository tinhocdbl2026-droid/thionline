import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playBalloonPop, playBallBounceSound } from '../../utils/soundEffects';

interface BalloonPopProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

interface BalloonParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
}

const BALLOON_COLORS = [
  '#EF4444', '#F97316', '#F59E0B', '#10B981', '#06B6D4',
  '#3B82F6', '#8B5CF6', '#EC4899', '#14B8A6'
];

export const BalloonPopMode: React.FC<BalloonPopProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [balloonScale, setBalloonScale] = useState(1);
  const [isPopped, setIsPopped] = useState(false);
  const [particles, setParticles] = useState<BalloonParticle[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const spinStartRef = useRef<number | null>(null);
  const hasEndedRef = useRef(false);

  useEffect(() => {
    if (isSpinning && availableStudents.length > 0) {
      setIsPopped(false);
      setBalloonScale(1);
      setParticles([]);
      hasEndedRef.current = false;
      spinStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * availableStudents.length);
      const winner = availableStudents[winnerIdx];
      setSelectedStudent(winner);
    }
  }, [isSpinning, availableStudents]);

  // Main animation
  useEffect(() => {
    if (!isSpinning) return;

    const animatePop = (time: number) => {
      if (!spinStartRef.current || !selectedStudent) return;
      const elapsed = (time - spinStartRef.current) / 1000;
      const totalDur = duration;

      if (elapsed < totalDur * 0.75) {
        // Fast drifting & inflating
        const progress = elapsed / (totalDur * 0.75);
        setBalloonScale(1 + progress * 1.6); // Inflate larger and larger!
      } else if (!hasEndedRef.current) {
        // POP EXPLOSION!
        hasEndedRef.current = true;
        setIsPopped(true);

        if (soundEnabled) {
          playBalloonPop(soundVolume);
        }

        // Spawn colorful burst particles
        const newParticles: BalloonParticle[] = [...Array(32)].map(() => {
          const angle = Math.random() * Math.PI * 2;
          const speed = 3 + Math.random() * 8;
          return {
            x: 0,
            y: 0,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            color: BALLOON_COLORS[Math.floor(Math.random() * BALLOON_COLORS.length)],
            size: 6 + Math.random() * 8,
          };
        });
        setParticles(newParticles);

        setTimeout(() => {
          onSpinEnd(selectedStudent);
        }, 650);
      }

      animFrameRef.current = requestAnimationFrame(animatePop);
    };

    animFrameRef.current = requestAnimationFrame(animatePop);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, selectedStudent, soundEnabled, soundVolume, onSpinEnd]);

  // Particle physics update
  useEffect(() => {
    if (particles.length === 0) return;

    const timer = setInterval(() => {
      setParticles(prev =>
        prev.map(p => ({
          ...p,
          x: p.x + p.vx,
          y: p.y + p.vy + 0.3, // slight gravity
          size: Math.max(0, p.size - 0.25),
        }))
      );
    }, 20);

    return () => clearInterval(timer);
  }, [particles]);

  const activeStudent = selectedStudent || availableStudents[0];

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Sky Room Stage - MAXIMUM EXPANSION */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] bg-gradient-to-b from-amber-100 via-sky-100 to-sky-200 rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-amber-300 relative overflow-hidden flex flex-col items-center justify-center">
        {/* Floating background clouds */}
        <div className="absolute top-4 left-6 text-5xl opacity-40 animate-float-slow">☁️</div>
        <div className="absolute top-10 right-8 text-4xl opacity-40 animate-float-slow">☁️</div>

        {/* Center Target Balloon - GIANT SCALE */}
        <div className="relative flex flex-col items-center justify-center">
          {!isPopped ? (
            <div
              className="relative flex flex-col items-center transition-transform"
              style={{
                transform: `scale(${balloonScale})`,
              }}
            >
              {/* Giant Party Balloon */}
              <div className="w-60 h-72 sm:w-72 sm:h-84 md:w-80 md:h-96 rounded-[50%_50%_50%_50%_/_40%_40%_60%_60%] bg-gradient-to-tr from-rose-600 via-rose-500 to-rose-300 shadow-2xl flex flex-col items-center justify-center relative border-4 border-white/80">
                {/* Shiny reflection */}
                <div className="absolute top-6 left-8 w-12 h-20 bg-white/40 rounded-full transform -rotate-25" />

                {/* Number & Name Tag */}
                <span className="text-white font-mono font-black text-6xl sm:text-7xl drop-shadow-lg mb-2">
                  {activeStudent?.number}
                </span>
                <span className="text-white font-black text-2xl sm:text-3xl px-4 truncate max-w-[240px] sm:max-w-[300px] text-center drop-shadow-md">
                  {activeStudent?.name}
                </span>
              </div>

              {/* Tied Knot & String */}
              <div className="w-5 h-4 bg-rose-700 rounded-b-sm" />
              <div className="w-[3px] h-16 bg-slate-400/80 shadow-xs" />
            </div>
          ) : (
            /* Pop Exploded Burst Stage */
            <div className="relative flex items-center justify-center">
              <span className="text-9xl animate-ping">💥</span>

              {/* Exploding particles */}
              {particles.map((p, i) => (
                <div
                  key={i}
                  className="absolute rounded-full"
                  style={{
                    transform: `translate(${p.x}px, ${p.y}px)`,
                    width: `${p.size * 1.5}px`,
                    height: `${p.size * 1.5}px`,
                    backgroundColor: p.color,
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Subtle overlay pill at bottom */}
        <div className="absolute bottom-2 bg-slate-900/60 text-white font-medium text-xs px-4 py-1 rounded-full backdrop-blur-xs border border-white/20 shadow-md pointer-events-none">
          🎈 Bong bóng căng phồng rồi phát nổ để gọi tên học sinh!
        </div>
      </div>
    </div>
  );
};
