import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playFishBiteSound } from '../../utils/soundEffects';

interface FishingPondProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

interface FishItem {
  student: Student;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  finColor: string;
  tailPhase: number;
  facingRight: boolean;
  scale: number;
}

const FISH_PALETTES = [
  { body: '#F97316', fin: '#FDE047' }, // Clownfish Orange & Yellow
  { body: '#3B82F6', fin: '#67E8F9' }, // Tang Blue & Cyan
  { body: '#EC4899', fin: '#F472B6' }, // Coral Pink
  { body: '#10B981', fin: '#A7F3D0' }, // Emerald Teal
  { body: '#8B5CF6', fin: '#C4B5FD' }, // Royal Purple
  { body: '#EF4444', fin: '#FCA5A5' }, // Ruby Red
  { body: '#F59E0B', fin: '#FEF08A' }, // Golden Yellow
];

// High-fidelity Animated Tropical Fish SVG
const AnimatedFishSVG: React.FC<{
  bodyColor: string;
  finColor: string;
  tailAngle: number;
  facingRight: boolean;
  name: string;
  number: number;
}> = ({ bodyColor, finColor, tailAngle, facingRight, name, number }) => {
  return (
    <div
      className="flex items-center gap-1.5 transition-transform duration-75 select-none"
      style={{
        transform: `scaleX(${facingRight ? 1 : -1})`,
      }}
    >
      <svg
        viewBox="0 0 100 60"
        className="w-24 h-14 sm:w-28 sm:h-16 overflow-visible drop-shadow-md"
      >
        <defs>
          <linearGradient id={`fishBody_${bodyColor}`} x1="0%" y1="0%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.4" />
            <stop offset="30%" stopColor={bodyColor} />
            <stop offset="100%" stopColor={bodyColor} />
          </linearGradient>
        </defs>

        {/* Waving Tail Fin with animated angle */}
        <g transform={`translate(18, 30) rotate(${tailAngle})`}>
          <path
            d="M0,0 C-14,-16 -24,-14 -30,-6 C-24,0 -24,0 -30,6 C-24,14 -14,16 0,0 Z"
            fill={finColor}
            stroke="#FFFFFF"
            strokeWidth="1.2"
          />
          {/* Tail fin ray lines */}
          <path d="M-4,0 L-26,-4" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.6" />
          <path d="M-4,0 L-26,4" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.6" />
        </g>

        {/* Dorsal Fin (Top) */}
        <path
          d="M40,16 Q52,4 68,14 Q52,12 40,16 Z"
          fill={finColor}
          stroke="#FFFFFF"
          strokeWidth="1"
        />

        {/* Ventral Fin (Bottom) */}
        <path
          d="M48,44 Q56,54 66,46 Q54,46 48,44 Z"
          fill={finColor}
          stroke="#FFFFFF"
          strokeWidth="1"
        />

        {/* Fish Streamlined Body */}
        <path
          d="M16,30 Q30,12 65,16 Q88,20 94,30 Q88,40 65,44 Q30,48 16,30 Z"
          fill={`url(#fishBody_${bodyColor})`}
          stroke="#FFFFFF"
          strokeWidth="1.5"
        />

        {/* Decorative Tropical Stripes */}
        <path d="M46,16 Q42,30 46,44" stroke="#FFFFFF" strokeWidth="2.5" fill="none" opacity="0.75" />
        <path d="M60,18 Q56,30 60,42" stroke="#FFFFFF" strokeWidth="2.5" fill="none" opacity="0.75" />

        {/* Pectoral Fin (Flapping) */}
        <ellipse
          cx="48"
          cy="32"
          rx="8"
          ry="5"
          fill={finColor}
          stroke="#FFFFFF"
          strokeWidth="0.8"
          transform="rotate(-20, 48, 32)"
        />

        {/* Eye */}
        <circle cx="80" cy="26" r="5" fill="#FFFFFF" />
        <circle cx="82" cy="26" r="2.8" fill="#0F172A" />
        <circle cx="83.5" cy="24.5" r="1.2" fill="#FFFFFF" />

        {/* Smile mouth */}
        <path d="M88,33 Q84,36 80,34" stroke="#475569" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      </svg>

      {/* Floating Student Name Tag */}
      <div
        className="bg-white/95 px-3 py-1 rounded-full shadow-md border border-sky-300 text-xs sm:text-base font-black text-slate-800 whitespace-nowrap"
        style={{
          transform: `scaleX(${facingRight ? 1 : -1})`,
        }}
      >
        <span className="text-sky-600 mr-1 font-mono font-black">{number}.</span>
        {name}
      </div>
    </div>
  );
};

export const FishingPondMode: React.FC<FishingPondProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [fishes, setFishes] = useState<FishItem[]>([]);
  const [hookY, setHookY] = useState(16); // percentage 10 to 65%
  const [hookX, setHookX] = useState(50);
  const [caughtFish, setCaughtFish] = useState<FishItem | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const fishStartRef = useRef<number | null>(null);
  const targetWinnerRef = useRef<Student | null>(null);
  const hasHookedRef = useRef(false);
  const tailOscRef = useRef(0);

  // Initialize lively fish
  useEffect(() => {
    const newFishes: FishItem[] = availableStudents.map((st, idx) => {
      const palette = FISH_PALETTES[idx % FISH_PALETTES.length];
      const movingRight = Math.random() > 0.5;
      return {
        student: st,
        x: 10 + Math.random() * 75,
        y: 35 + Math.random() * 45,
        vx: (movingRight ? 1 : -1) * (0.25 + Math.random() * 0.35),
        vy: (Math.random() - 0.5) * 0.15,
        color: palette.body,
        finColor: palette.fin,
        tailPhase: Math.random() * Math.PI * 2,
        facingRight: movingRight,
        scale: 0.95 + Math.random() * 0.15,
      };
    });
    setFishes(newFishes);
  }, [availableStudents]);

  // Handle spin / casting
  useEffect(() => {
    if (isSpinning && availableStudents.length > 0) {
      hasHookedRef.current = false;
      setCaughtFish(null);
      fishStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * availableStudents.length);
      const winner = availableStudents[winnerIdx];
      targetWinnerRef.current = winner;
    }
  }, [isSpinning, availableStudents]);

  // Main 60FPS fluid physics loop
  useEffect(() => {
    const updatePond = (time: number) => {
      tailOscRef.current += 0.22;

      // 1. Smoothly swim all active fish
      setFishes(prev =>
        prev.map(f => {
          if (caughtFish && f.student.id === caughtFish.student.id) return f;

          let newX = f.x + f.vx;
          let newY = f.y + Math.sin(time * 0.003 + f.tailPhase) * 0.25;
          let newFacing = f.facingRight;

          // Soft boundary bounce with turnaround
          if (newX > 82) {
            newX = 82;
            f.vx = -Math.abs(f.vx);
            newFacing = false;
          } else if (newX < 6) {
            newX = 6;
            f.vx = Math.abs(f.vx);
            newFacing = true;
          }

          if (newY < 28) newY = 28;
          if (newY > 82) newY = 82;

          return {
            ...f,
            x: newX,
            y: newY,
            facingRight: newFacing,
          };
        })
      );

      // 2. Fishing line casting & hooking animation
      if (isSpinning && fishStartRef.current && targetWinnerRef.current) {
        const elapsed = (time - fishStartRef.current) / 1000;
        const totalDur = Math.max(1.5, duration);

        if (elapsed < totalDur * 0.65) {
          // Bobber & line descend smoothly with realistic water drag
          const castProgress = Math.min(1, elapsed / (totalDur * 0.65));
          // Cubic ease-in-out drop
          const easeDrop = castProgress < 0.5 ? 2 * castProgress * castProgress : -1 + (4 - 2 * castProgress) * castProgress;
          setHookY(16 + easeDrop * 46);
          setHookX(50 + Math.sin(time * 0.003) * 16);
        } else {
          // Fish is hooked!
          if (!hasHookedRef.current) {
            hasHookedRef.current = true;
            const target = fishes.find(f => f.student.id === targetWinnerRef.current?.id) || fishes[0];
            setCaughtFish(target);

            if (soundEnabled) {
              playFishBiteSound(soundVolume);
            }

            setTimeout(() => {
              if (targetWinnerRef.current) {
                onSpinEnd(targetWinnerRef.current);
              }
            }, 750);
          }

          // Reel up smoothly with dramatic splash
          const reelProgress = Math.min(1, (elapsed - totalDur * 0.65) / (totalDur * 0.35));
          const easeReel = Math.pow(reelProgress, 1.8);
          setHookY(62 - easeReel * 46);
        }
      } else if (!isSpinning) {
        setHookY(16);
        setHookX(50);
      }

      animFrameRef.current = requestAnimationFrame(updatePond);
    };

    animFrameRef.current = requestAnimationFrame(updatePond);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, caughtFish, fishes, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Crystal Clear Cartoon Lagoon - MAXIMUM WIDTH & HEIGHT */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] bg-gradient-to-b from-sky-400 via-cyan-500 to-blue-800 rounded-3xl p-3 sm:p-4 shadow-2xl border-4 border-cyan-300 relative overflow-hidden flex flex-col justify-between">
        {/* Sunlit Water Highlights & Shimmer */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,#ffffff40,transparent_70%)] pointer-events-none" />

        {/* Lagoon Shoreline Header */}
        <div className="relative z-30 flex items-center justify-between border-b border-white/40 pb-2 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-2xl drop-shadow">🎣</span>
            <span className="text-white font-display text-sm sm:text-base font-black tracking-wider uppercase drop-shadow-md">
              HỒ CÂU CÁ HOẠT HÌNH
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-bold text-cyan-100">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span>{availableStudents.length} chú cá đang bơi</span>
          </div>
        </div>

        {/* Curved Fishing Line & Hook with Bobber */}
        <div
          className="absolute z-40 transition-all pointer-events-none"
          style={{
            left: `${hookX}%`,
            top: 0,
            height: `${hookY}%`,
          }}
        >
          {/* Fishing Monofilament Line */}
          <div className="w-[2px] h-full bg-white/90 shadow-sm" />

          {/* Red & White Striped Bobber Floating at surface */}
          <div className="absolute -top-1 -left-2 w-4 h-4 rounded-full bg-gradient-to-b from-red-500 via-white to-red-500 shadow-md border border-white/60 animate-bounce" />

          {/* Golden Curved Hook */}
          <div className="text-2xl -ml-2.5 -mt-1 transform rotate-45 filter drop-shadow-md">
            🪝
          </div>

          {/* Hooked Lucky Fish Reeling Upwards */}
          {caughtFish && (
            <div className="absolute top-full -left-12 flex flex-col items-center animate-bounce">
              <AnimatedFishSVG
                bodyColor={caughtFish.color}
                finColor={caughtFish.finColor}
                tailAngle={Math.sin(tailOscRef.current * 2) * 28}
                facingRight={true}
                name={caughtFish.student.name}
                number={caughtFish.student.number}
              />
              <span className="bg-yellow-300 text-slate-950 font-black text-xs px-3 py-1 rounded-full shadow-xl border-2 border-white mt-1 whitespace-nowrap animate-pulse">
                ĐÃ CẮN CÂU! 🎉
              </span>
            </div>
          )}
        </div>

        {/* Swimming Fish in the Water */}
        <div className="relative flex-1 z-20 overflow-hidden">
          {fishes.map(f => {
            const isHooked = caughtFish && f.student.id === caughtFish.student.id;
            if (isHooked) return null; // Rendered on the hook

            return (
              <div
                key={f.student.id}
                className="absolute will-change-transform transition-transform duration-75 ease-out"
                style={{
                  transform: `translate3d(${f.x}%, ${f.y}%, 0) scale(${f.scale})`,
                }}
              >
                <AnimatedFishSVG
                  bodyColor={f.color}
                  finColor={f.finColor}
                  tailAngle={Math.sin(tailOscRef.current + f.tailPhase) * 22}
                  facingRight={f.facingRight}
                  name={f.student.name}
                  number={f.student.number}
                />
              </div>
            );
          })}
        </div>

        {/* Sea Bed with Coral, Seaweed & Bubbles */}
        <div className="relative z-10 flex justify-around items-end pt-2 text-3xl opacity-80 pointer-events-none">
          <span className="animate-float-slow">🌿</span>
          <span className="text-xl animate-bounce">🫧</span>
          <span className="animate-pulse">🪸</span>
          <span className="text-xl animate-bounce delay-150">🫧</span>
          <span className="animate-float-slow">🌿</span>
          <span>🐚</span>
        </div>
      </div>

      <div className="text-center mt-1.5 text-slate-500 text-xs font-semibold">
        Câu cá hoạt hình 60 FPS · Cần câu thả xuống hồ để bắt chú cá may mắn!
      </div>
    </div>
  );
};
