import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playRocketLaunchSound } from '../../utils/soundEffects';

interface RocketLaunchProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

interface RocketRunner {
  student: Student;
  altitude: number; // 0 to 100%
  color: string;
  thrust: number;
}

const ROCKET_PALETTES = [
  '#DC2626', '#EA580C', '#2563EB', '#16A34A', '#7C3AED', '#DB2777'
];

// High-fidelity Cartoon Space Rocket SVG
const AnimatedRocketSVG: React.FC<{
  color: string;
  isLaunching: boolean;
}> = ({ color, isLaunching }) => {
  return (
    <div className="relative flex flex-col items-center select-none">
      <svg
        viewBox="0 0 60 110"
        className="w-12 h-20 sm:w-14 sm:h-24 overflow-visible drop-shadow-xl"
      >
        <defs>
          <linearGradient id={`rocketGrad_${color}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.4" />
            <stop offset="40%" stopColor="#F8FAFC" />
            <stop offset="100%" stopColor="#CBD5E1" />
          </linearGradient>
        </defs>

        {/* Thruster Flames (Animated when launching) */}
        {isLaunching && (
          <g transform="translate(30, 85)">
            {/* Outer flame */}
            <path
              d="M-9,0 Q0,32 0,42 Q0,32 9,0 Z"
              fill="#F97316"
              className="animate-pulse"
            />
            {/* Inner flame core */}
            <path
              d="M-5,0 Q0,20 0,26 Q0,20 5,0 Z"
              fill="#FDE047"
            />
            {/* Blue hot plasma spark */}
            <ellipse cx="0" cy="4" rx="3.5" ry="5" fill="#38BDF8" />
          </g>
        )}

        {/* Rocket Engine Nozzle */}
        <polygon points="21,80 39,80 36,88 24,88" fill="#334155" />

        {/* Left Booster Fin */}
        <path d="M16,56 Q8,70 6,84 L19,78 Z" fill={color} stroke="#FFFFFF" strokeWidth="1" />

        {/* Right Booster Fin */}
        <path d="M44,56 Q52,70 54,84 L41,78 Z" fill={color} stroke="#FFFFFF" strokeWidth="1" />

        {/* Center Rocket Fuselage Body */}
        <path
          d="M30,10 Q14,35 16,80 L44,80 Q46,35 30,10 Z"
          fill={`url(#rocketGrad_${color})`}
          stroke="#94A3B8"
          strokeWidth="1.2"
        />

        {/* Nosecone in Team Color */}
        <path
          d="M30,10 Q21,26 19,36 L41,36 Q39,26 30,10 Z"
          fill={color}
          stroke="#FFFFFF"
          strokeWidth="1"
        />

        {/* Circular Porthole Window with Astronaut */}
        <circle cx="30" cy="50" r="9" fill="#0F172A" stroke="#FFFFFF" strokeWidth="2" />
        <circle cx="30" cy="50" r="7" fill="#38BDF8" opacity="0.8" />
        {/* Astronaut visor reflection */}
        <path d="M25,48 Q30,44 35,48" stroke="#FFFFFF" strokeWidth="1.5" fill="none" />
      </svg>
    </div>
  );
};

export const RocketLaunchMode: React.FC<RocketLaunchProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [rockets, setRockets] = useState<RocketRunner[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const launchStartRef = useRef<number | null>(null);
  const targetWinnerRef = useRef<Student | null>(null);
  const hasReachedRef = useRef(false);

  const initRockets = () => {
    if (availableStudents.length === 0) return;
    const pool = [...availableStudents];
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }

    const count = Math.min(6, Math.max(3, pool.length));
    const selected = pool.slice(0, count);

    setRockets(
      selected.map((st, idx) => ({
        student: st,
        altitude: 0,
        color: ROCKET_PALETTES[idx % ROCKET_PALETTES.length],
        thrust: 0.88 + Math.random() * 0.25,
      }))
    );
  };

  useEffect(() => {
    initRockets();
  }, [availableStudents]);

  useEffect(() => {
    if (isSpinning && rockets.length > 0) {
      hasReachedRef.current = false;
      launchStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * rockets.length);
      const winner = rockets[winnerIdx].student;
      targetWinnerRef.current = winner;

      if (soundEnabled) {
        playRocketLaunchSound(soundVolume);
      }

      setRockets(prev =>
        prev.map((r, i) => ({
          ...r,
          altitude: 0,
          thrust: i === winnerIdx ? 1.06 : 0.82 + Math.random() * 0.12,
        }))
      );
    }
  }, [isSpinning]);

  // High-performance 60FPS vertical flight animation loop
  useEffect(() => {
    if (!isSpinning) return;

    const animateRockets = (time: number) => {
      if (!launchStartRef.current || !targetWinnerRef.current) return;
      const elapsed = (time - launchStartRef.current) / 1000;
      const totalDur = Math.max(1.5, duration);

      // Smooth custom launch curve: starts with steady roar, then surges into orbit
      const tNorm = Math.min(1, elapsed / totalDur);
      const baseAlt = Math.pow(tNorm, 1.6) * 100;

      setRockets(prev =>
        prev.map(r => {
          const isWinner = r.student.id === targetWinnerRef.current?.id;
          const wobble = Math.sin(time * 0.008 + r.student.number) * 2;
          const targetAlt = isWinner ? 100 : 92;
          const alt = Math.min(targetAlt, baseAlt * r.thrust + wobble);
          return {
            ...r,
            altitude: Math.max(0, alt),
          };
        })
      );

      if (elapsed >= totalDur && !hasReachedRef.current) {
        hasReachedRef.current = true;
        setRockets(prev =>
          prev.map(r => ({
            ...r,
            altitude: r.student.id === targetWinnerRef.current?.id ? 100 : r.altitude,
          }))
        );

        setTimeout(() => {
          if (targetWinnerRef.current) {
            onSpinEnd(targetWinnerRef.current);
          }
        }, 500);
      } else {
        animFrameRef.current = requestAnimationFrame(animateRockets);
      }
    };

    animFrameRef.current = requestAnimationFrame(animateRockets);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Cosmos Launch Station - MAXIMUM EXPANSION */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] bg-gradient-to-b from-indigo-950 via-slate-900 to-slate-950 rounded-3xl p-3 sm:p-4 shadow-2xl border-4 border-indigo-400 relative overflow-hidden flex flex-col justify-between">
        {/* Twinkling stars */}
        <div className="absolute inset-0 pointer-events-none opacity-40">
          {[...Array(24)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full animate-ping"
              style={{
                top: `${(i * 17) % 95}%`,
                left: `${(i * 29) % 95}%`,
                animationDuration: `${1.5 + (i % 3)}s`,
              }}
            />
          ))}
        </div>

        {/* Target Orbit / Lunar Destination */}
        <div className="relative z-20 flex items-center justify-between border-b border-indigo-700/50 pb-2 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-2xl animate-spin-slow">🌕</span>
            <span className="text-white font-display text-sm sm:text-base font-black tracking-wider uppercase drop-shadow">
              TRẠM VŨ TRỤ MẶT TRĂNG
            </span>
          </div>

          <button
            onClick={() => {
              if (!isSpinning) initRockets();
            }}
            disabled={isSpinning}
            className="text-indigo-300 hover:text-white underline text-xs font-bold cursor-pointer transition-colors"
          >
            Đổi phi đội tên lửa
          </button>
        </div>

        {/* Launchpad Columns */}
        <div className="relative flex-1 flex items-end justify-around px-2 pt-4 pb-2 z-10 overflow-hidden">
          {rockets.map(r => {
            const isWinnerInOrbit = hasReachedRef.current && r.student.id === targetWinnerRef.current?.id;

            return (
              <div key={r.student.id} className="relative flex flex-col items-center h-full justify-end">
                {/* Rocket ascending using hardware-accelerated translate3d */}
                <div
                  className="absolute flex flex-col items-center will-change-transform transition-transform duration-75 ease-out"
                  style={{
                    transform: `translate3d(0, -${r.altitude * 2.3}px, 0)`,
                  }}
                >
                  {/* High Quality Vector Rocket SVG */}
                  <AnimatedRocketSVG
                    color={r.color}
                    isLaunching={isSpinning}
                  />

                  {/* Student Name Card - BIGGER TEXT */}
                  <div
                    className={`mt-1 px-3 py-1.5 rounded-xl text-xs sm:text-base font-extrabold truncate max-w-[120px] sm:max-w-[160px] text-center shadow-md border transition-all ${
                      isWinnerInOrbit
                        ? 'bg-yellow-300 text-slate-950 font-black border-white scale-110 shadow-lg'
                        : 'bg-white/95 text-slate-800 border-slate-200'
                    }`}
                  >
                    {r.student.name}
                  </div>
                </div>

                {/* Metallic Launch Pad Base */}
                <div className="w-16 h-4 bg-gradient-to-r from-slate-700 via-slate-600 to-slate-700 rounded-t-lg border-t-2 border-indigo-400/80 shadow-md" />
              </div>
            );
          })}
        </div>

        {/* Bottom subtle label */}
        <div className="text-center mt-1.5 text-indigo-300/80 text-xs font-semibold shrink-0">
          🚀 Tên lửa vũ trụ 60 FPS · Tên lửa phụt lửa bay cao nhất chạm tới quỹ đạo sẽ được gọi tên!
        </div>
      </div>
    </div>
  );
};
