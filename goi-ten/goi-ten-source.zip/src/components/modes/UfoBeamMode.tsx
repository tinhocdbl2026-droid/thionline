import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playUfoBeamSound } from '../../utils/soundEffects';

interface UfoBeamProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

// High-fidelity Alien UFO Saucer SVG
const AnimatedUfoSaucerSVG: React.FC<{
  isHovering: boolean;
  isBeaming: boolean;
}> = ({ isBeaming }) => {
  return (
    <div className="relative flex flex-col items-center select-none">
      <svg
        viewBox="0 0 140 70"
        className="w-24 h-12 sm:w-28 sm:h-14 overflow-visible drop-shadow-2xl"
      >
        <defs>
          <linearGradient id="ufoDomeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#A5F3FC" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#06B6D4" stopOpacity="0.75" />
            <stop offset="100%" stopColor="#0891B2" stopOpacity="0.85" />
          </linearGradient>
          <linearGradient id="ufoHullGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#64748B" />
            <stop offset="30%" stopColor="#E2E8F0" />
            <stop offset="70%" stopColor="#F8FAFC" />
            <stop offset="100%" stopColor="#475569" />
          </linearGradient>
        </defs>

        {/* Dome Cockpit */}
        <path
          d="M45,26 Q70,4 95,26 Z"
          fill="url(#ufoDomeGrad)"
          stroke="#FFFFFF"
          strokeWidth="1.5"
        />

        {/* Cute Alien inside cockpit */}
        <g transform="translate(64, 14)">
          {/* Alien Head */}
          <ellipse cx="6" cy="7" rx="5" ry="6" fill="#4ADE80" />
          {/* Big Black Eyes */}
          <ellipse cx="4" cy="6" rx="1.8" ry="2.2" fill="#0F172A" transform="rotate(-15, 4, 6)" />
          <ellipse cx="8" cy="6" rx="1.8" ry="2.2" fill="#0F172A" transform="rotate(15, 8, 6)" />
          {/* Antenna */}
          <line x1="6" y1="1" x2="6" y2="-2" stroke="#4ADE80" strokeWidth="1.2" />
          <circle cx="6" cy="-3" r="1.5" fill="#FDE047" />
        </g>

        {/* Main Saucer Disc Hull */}
        <ellipse
          cx="70"
          cy="32"
          rx="62"
          ry="16"
          fill="url(#ufoHullGrad)"
          stroke="#FFFFFF"
          strokeWidth="1.5"
        />

        {/* Hull Edge Rim */}
        <path
          d="M10,32 Q70,46 130,32 Q70,38 10,32 Z"
          fill="#334155"
        />

        {/* Pulsing Colored Beacon Lights */}
        <circle cx="26" cy="34" r="3.2" fill="#38BDF8" className="animate-ping" />
        <circle cx="48" cy="38" r="3.2" fill="#FDE047" className="animate-pulse" />
        <circle cx="70" cy="40" r="3.5" fill="#4ADE80" className="animate-ping" />
        <circle cx="92" cy="38" r="3.2" fill="#F43F5E" className="animate-pulse" />
        <circle cx="114" cy="34" r="3.2" fill="#A855F7" className="animate-ping" />

        {/* Bottom Emitter Ring */}
        <ellipse cx="70" cy="42" rx="20" ry="5" fill="#0F172A" />
        <ellipse
          cx="70"
          cy="42"
          rx="14"
          ry="3.5"
          fill={isBeaming ? '#4ADE80' : '#38BDF8'}
        />
      </svg>
    </div>
  );
};

export const UfoBeamMode: React.FC<UfoBeamProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [ufoX, setUfoX] = useState(50); // percentage 10 to 90
  const [beamActive, setBeamActive] = useState(false);
  const [targetWinner, setTargetWinner] = useState<Student | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const spinStartRef = useRef<number | null>(null);
  const hasBeamedRef = useRef(false);

  // Pool of visible students below
  const [visibleStudents, setVisibleStudents] = useState<Student[]>([]);

  useEffect(() => {
    const count = Math.min(6, Math.max(3, availableStudents.length));
    const pool = [...availableStudents].slice(0, count);
    setVisibleStudents(pool);
  }, [availableStudents]);

  useEffect(() => {
    if (isSpinning && visibleStudents.length > 0) {
      setBeamActive(false);
      hasBeamedRef.current = false;
      spinStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * visibleStudents.length);
      const winner = visibleStudents[winnerIdx];
      setTargetWinner(winner);
    }
  }, [isSpinning, visibleStudents]);

  // Main 60FPS animation
  useEffect(() => {
    if (!isSpinning) return;

    const animateUfo = (time: number) => {
      if (!spinStartRef.current || !targetWinner) return;
      const elapsed = (time - spinStartRef.current) / 1000;
      const totalDur = Math.max(1.5, duration);

      const targetIdx = visibleStudents.findIndex(s => s.id === targetWinner.id);
      const targetXPos = ((targetIdx + 0.5) / visibleStudents.length) * 100;

      if (elapsed < totalDur * 0.7) {
        // Smooth sine wave search sweep
        const sweep = Math.sin(time * 0.005) * 36 + 50;
        setUfoX(sweep);
      } else {
        // Smoothly lock onto target student
        setUfoX(prev => prev + (targetXPos - prev) * 0.15);

        if (!hasBeamedRef.current) {
          hasBeamedRef.current = true;
          setBeamActive(true);

          if (soundEnabled) {
            playUfoBeamSound(soundVolume);
          }

          setTimeout(() => {
            onSpinEnd(targetWinner);
          }, 850);
        }
      }

      animFrameRef.current = requestAnimationFrame(animateUfo);
    };

    animFrameRef.current = requestAnimationFrame(animateUfo);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, targetWinner, visibleStudents, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Sci-Fi Stage - MAXIMUM EXPANSION */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] bg-gradient-to-b from-slate-950 via-indigo-950 to-slate-900 rounded-3xl p-4 sm:p-5 shadow-2xl border-4 border-emerald-400 relative overflow-hidden flex flex-col justify-between">
        {/* Distant stars */}
        <div className="absolute inset-0 pointer-events-none opacity-30">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full animate-ping"
              style={{
                top: `${(i * 19) % 90}%`,
                left: `${(i * 31) % 90}%`,
                animationDuration: `${2 + (i % 3)}s`,
              }}
            />
          ))}
        </div>

        {/* UFO Flying Spaceship with Hardware Acceleration */}
        <div
          className="absolute z-30 flex flex-col items-center will-change-transform transition-transform duration-75 ease-out"
          style={{
            left: `${ufoX}%`,
            top: '25px',
            transform: 'translateX(-50%)',
          }}
        >
          {/* High-Fidelity Animated UFO SVG */}
          <AnimatedUfoSaucerSVG
            isHovering={isSpinning}
            isBeaming={beamActive}
          />

          {/* Luminous Tractor Beam with Scanning Rings */}
          {beamActive && (
            <div
              className="w-44 h-80 bg-gradient-to-b from-emerald-400/80 via-emerald-300/40 to-transparent pointer-events-none -mt-2 animate-pulse-subtle flex flex-col justify-around items-center"
              style={{
                clipPath: 'polygon(30% 0%, 70% 0%, 100% 100%, 0% 100%)',
              }}
            >
              <div className="w-16 h-2 rounded-full bg-white/70 animate-ping" />
              <div className="w-28 h-2.5 rounded-full bg-white/80 animate-ping delay-100" />
              <div className="w-36 h-3 rounded-full bg-white/90 animate-ping delay-200" />
            </div>
          )}
        </div>

        {/* Ground Surface with Student Characters */}
        <div className="relative z-10 w-full flex items-end justify-around pt-12 pb-3 mt-auto border-t-2 border-emerald-500/50 bg-slate-900/70 rounded-2xl backdrop-blur-xs">
          {visibleStudents.map((st) => {
            const isBeamed = beamActive && targetWinner?.id === st.id;

            return (
              <div
                key={st.id}
                className={`flex flex-col items-center transition-all duration-300 ${
                  isBeamed ? '-translate-y-12 scale-125 z-30' : ''
                }`}
              >
                {/* Student Avatar / Mascot */}
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 border-2 border-white/80 text-white flex items-center justify-center font-black text-lg shadow-md mb-1">
                  {st.number}
                </div>

                {/* Name Tag */}
                <div
                  className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-base font-extrabold truncate max-w-[120px] sm:max-w-[160px] text-center shadow-sm border transition-all ${
                    isBeamed
                      ? 'bg-emerald-400 text-slate-950 font-black border-white shadow-xl shadow-emerald-400/60'
                      : 'bg-white/95 text-slate-800 border-slate-200'
                  }`}
                >
                  {st.name}
                </div>
              </div>
            );
          })}
        </div>

        {/* Subtle overlay pill at bottom */}
        <div className="absolute top-3 right-4 bg-slate-900/70 text-emerald-300 font-medium text-xs px-3.5 py-1 rounded-full backdrop-blur-xs border border-emerald-400/30 shadow-md pointer-events-none">
          🛸 Đĩa bay UFO đang quét chùm tia hút
        </div>
      </div>
    </div>
  );
};
