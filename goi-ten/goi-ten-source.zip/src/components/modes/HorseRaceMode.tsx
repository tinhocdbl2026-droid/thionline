import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playHorseGallop } from '../../utils/soundEffects';

interface HorseRaceProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

interface HorseRunner {
  student: Student;
  lane: number;
  progress: number; // 0 to 100%
  color: string;
  speedMultiplier: number;
  bobOffset: number;
}

const HORSE_COLORS = [
  '#DC2626', // Red
  '#EA580C', // Orange
  '#D97706', // Amber
  '#16A34A', // Emerald
  '#0284C7', // Sky Blue
  '#4F46E5', // Indigo
  '#9333EA', // Purple
  '#DB2777', // Pink
];

// High-fidelity Animated Horse SVG Component with Jockey and Galloping Legs
const AnimatedHorseSVG: React.FC<{
  color: string;
  isGalloping: boolean;
  phase: number;
}> = ({ color, isGalloping, phase }) => {
  // Compute leg rotation based on gallop cycle
  const legAngle1 = isGalloping ? Math.sin(phase) * 32 : 0;
  const legAngle2 = isGalloping ? Math.sin(phase + Math.PI) * 32 : 0;
  const tailAngle = isGalloping ? Math.sin(phase * 1.5) * 18 - 15 : -10;

  return (
    <svg
      viewBox="0 0 120 80"
      className="w-16 h-11 sm:w-20 sm:h-14 overflow-visible drop-shadow-md select-none"
    >
      <defs>
        <linearGradient id={`horseCoat_${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#92400E" />
          <stop offset="60%" stopColor="#78350F" />
          <stop offset="100%" stopColor="#451A03" />
        </linearGradient>
        <linearGradient id={`jockeyGrad_${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="40%" stopColor={color} />
          <stop offset="100%" stopColor={color} />
        </linearGradient>
      </defs>

      {/* Tail with flowing motion */}
      <g transform={`translate(22, 44) rotate(${tailAngle})`}>
        <path
          d="M0,0 Q-18,6 -24,20 Q-12,14 0,4 Z"
          fill="#451A03"
          stroke="#270E02"
          strokeWidth="1"
        />
      </g>

      {/* Back Left Leg */}
      <g transform={`translate(32, 48) rotate(${legAngle2})`}>
        <path d="M0,0 L-6,18 L-2,28" stroke="#5F270B" strokeWidth="4.5" strokeLinecap="round" />
        <ellipse cx="-2" cy="28" rx="3.5" ry="2" fill="#1E293B" />
      </g>

      {/* Front Left Leg */}
      <g transform={`translate(78, 48) rotate(${legAngle1})`}>
        <path d="M0,0 L8,16 L12,28" stroke="#5F270B" strokeWidth="4.5" strokeLinecap="round" />
        <ellipse cx="12" cy="28" rx="3.5" ry="2" fill="#1E293B" />
      </g>

      {/* Horse Muscular Body */}
      <path
        d="M26,46 Q24,32 40,32 L72,34 Q86,34 84,48 Q76,56 46,56 Q30,56 26,46 Z"
        fill={`url(#horseCoat_${color})`}
      />

      {/* Saddlecloth & Saddle with Team Color */}
      <rect x="42" y="32" width="22" height="15" rx="3" fill={color} stroke="#FFFFFF" strokeWidth="1.5" />
      <path d="M48,34 Q53,40 58,34" stroke="#FEF08A" strokeWidth="2" fill="none" />

      {/* Jockey (Jockey rider in racing silks) */}
      <g transform="translate(47, 14)">
        {/* Jockey Helmet */}
        <circle cx="7" cy="4" r="5" fill={color} stroke="#FFFFFF" strokeWidth="1" />
        <path d="M7,4 L13,6" stroke="#FEF08A" strokeWidth="1.5" strokeLinecap="round" />
        {/* Jockey Body & Torso (leaning forward) */}
        <path d="M3,9 Q9,6 14,14 L7,17 Z" fill={`url(#jockeyGrad_${color})`} stroke="#1E293B" strokeWidth="0.8" />
        {/* Jockey Arm holding reins */}
        <path d="M9,11 L18,17" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" />
      </g>

      {/* Horse Neck and Head */}
      <path
        d="M74,38 Q84,24 94,14 Q98,12 104,18 Q106,24 98,28 L84,48 Z"
        fill={`url(#horseCoat_${color})`}
      />
      {/* Horse Muzzle */}
      <path d="M98,18 Q106,20 104,26 Q98,28 94,24 Z" fill="#5F270B" />
      {/* Eye & Ear */}
      <polygon points="90,14 94,6 96,14" fill="#78350F" />
      <circle cx="95" cy="18" r="1.5" fill="#FFFFFF" />
      <circle cx="95.5" cy="18" r="0.8" fill="#000000" />
      {/* Mane flowing in the wind */}
      <path
        d="M78,34 Q82,24 90,16 Q86,22 80,30 Z"
        fill="#270E02"
      />
      {/* Reins */}
      <path d="M65,31 Q80,32 98,24" stroke="#FEF08A" strokeWidth="1" fill="none" />

      {/* Back Right Leg (foreground) */}
      <g transform={`translate(36, 48) rotate(${legAngle1})`}>
        <path d="M0,0 L-4,18 L2,29" stroke="#78350F" strokeWidth="5" strokeLinecap="round" />
        <ellipse cx="2" cy="29" rx="3.5" ry="2" fill="#0F172A" />
      </g>

      {/* Front Right Leg (foreground) */}
      <g transform={`translate(84, 48) rotate(${legAngle2})`}>
        <path d="M0,0 L10,16 L16,29" stroke="#78350F" strokeWidth="5" strokeLinecap="round" />
        <ellipse cx="16" cy="29" rx="3.5" ry="2" fill="#0F172A" />
      </g>
    </svg>
  );
};

export const HorseRaceMode: React.FC<HorseRaceProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [runners, setRunners] = useState<HorseRunner[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const raceStartRef = useRef<number | null>(null);
  const targetWinnerRef = useRef<Student | null>(null);
  const hasFinishedRef = useRef(false);
  const lastGallopTimeRef = useRef(0);
  const gallopPhaseRef = useRef(0);

  // Initialize or re-shuffle 4 to 8 runners
  const initRunners = () => {
    if (availableStudents.length === 0) return;
    const pool = [...availableStudents];
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }

    const count = Math.min(6, Math.max(3, pool.length));
    const selected = pool.slice(0, count);

    setRunners(
      selected.map((st, idx) => ({
        student: st,
        lane: idx + 1,
        progress: 0,
        color: HORSE_COLORS[idx % HORSE_COLORS.length],
        speedMultiplier: 0.92 + Math.random() * 0.16,
        bobOffset: Math.random() * Math.PI * 2,
      }))
    );
  };

  useEffect(() => {
    initRunners();
  }, [availableStudents]);

  // Handle spin / race start
  useEffect(() => {
    if (isSpinning && runners.length > 0) {
      hasFinishedRef.current = false;
      raceStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * runners.length);
      const winner = runners[winnerIdx].student;
      targetWinnerRef.current = winner;

      setRunners(prev =>
        prev.map((r, i) => ({
          ...r,
          progress: 0,
          speedMultiplier: i === winnerIdx ? 1.05 : 0.85 + Math.random() * 0.12,
        }))
      );
    }
  }, [isSpinning]);

  // High-performance 60FPS animation loop using requestAnimationFrame
  useEffect(() => {
    if (!isSpinning) return;

    const updateRace = (time: number) => {
      if (!raceStartRef.current || !targetWinnerRef.current) return;
      const elapsed = (time - raceStartRef.current) / 1000;
      const totalDur = Math.max(1.5, duration);

      // Gallop leg cycle animation phase
      gallopPhaseRef.current += 0.35;

      // Gallop sound throttle
      if (soundEnabled && time - lastGallopTimeRef.current > 130) {
        playHorseGallop(soundVolume * 0.45);
        lastGallopTimeRef.current = time;
      }

      // Smooth custom acceleration curve (ease-in-out quintic progress)
      const tNorm = Math.min(1, elapsed / totalDur);
      // Quintic ease: gradual surge then dramatic photo-finish sprint
      const progressFactor = tNorm < 0.5 ? 4 * tNorm * tNorm * tNorm : 1 - Math.pow(-2 * tNorm + 2, 3) / 2;
      const baseProgress = progressFactor * 100;

      setRunners(prev =>
        prev.map(r => {
          const isWinner = r.student.id === targetWinnerRef.current?.id;
          // Organic speed variance: subtle surges that simulate living racehorses
          const surge = Math.sin(time * 0.006 + r.lane * 2.1) * 3.5;
          const targetProg = isWinner ? 100 : 93;
          const prog = Math.min(targetProg, baseProgress * r.speedMultiplier + surge);

          return {
            ...r,
            progress: Math.max(0, prog),
          };
        })
      );

      if (elapsed >= totalDur && !hasFinishedRef.current) {
        hasFinishedRef.current = true;
        setRunners(prev =>
          prev.map(r => ({
            ...r,
            progress: r.student.id === targetWinnerRef.current?.id ? 100 : r.progress,
          }))
        );

        setTimeout(() => {
          if (targetWinnerRef.current) {
            onSpinEnd(targetWinnerRef.current);
          }
        }, 500);
      } else {
        animFrameRef.current = requestAnimationFrame(updateRace);
      }
    };

    animFrameRef.current = requestAnimationFrame(updateRace);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isSpinning, duration, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      {/* Professional Turf Racecourse Arena - MAX HORIZONTAL WIDTH */}
      <div className="w-full h-full max-h-[calc(100vh-115px)] bg-gradient-to-b from-amber-800 via-amber-900 to-amber-950 rounded-3xl p-3 sm:p-4 shadow-2xl border-4 border-amber-500 relative overflow-hidden flex flex-col justify-between">
        {/* Racecourse Header */}
        <div className="flex items-center justify-between px-3 py-1.5 mb-2 text-white text-xs font-bold uppercase tracking-wider shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="font-display tracking-widest text-amber-200 text-sm sm:text-base font-black">ĐƯỜNG ĐUA NGỰA HOẠT HÌNH</span>
          </div>

          <button
            onClick={() => {
              if (!isSpinning) initRunners();
            }}
            disabled={isSpinning}
            className="text-amber-200 hover:text-white underline cursor-pointer text-xs font-bold transition-colors"
          >
            Đổi các chú ngựa
          </button>
        </div>

        {/* Turf Track Lanes - EXPANDED HORIZONTALLY */}
        <div className="space-y-1.5 sm:space-y-2 relative bg-emerald-950/70 p-2 sm:p-2.5 rounded-2xl border-2 border-emerald-700/60 shadow-inner overflow-hidden flex-1 overflow-y-auto min-h-0">
          {/* Finish Line Checkered Banner */}
          <div className="absolute right-16 top-0 bottom-0 w-4 z-20 pointer-events-none opacity-90 shadow-md">
            <div className="w-full h-full bg-[linear-gradient(45deg,#fff_25%,#000_25%,#000_50%,#fff_50%,#fff_75%,#000_75%,#000_100%)] bg-[length:14px_14px]" />
            <div className="absolute -top-1 -left-2 text-[10px] font-black text-yellow-300 uppercase tracking-tighter bg-slate-900 px-1 rounded-xs">
              ĐÍCH
            </div>
          </div>

          {runners.map((r) => {
            const isWinnerCrossing = hasFinishedRef.current && r.student.id === targetWinnerRef.current?.id;

            return (
              <div
                key={r.student.id}
                className="relative h-12 sm:h-14 bg-gradient-to-r from-emerald-800/90 via-emerald-700/90 to-emerald-800/90 rounded-xl border border-emerald-500/40 flex items-center overflow-hidden shadow-xs"
              >
                {/* Lane Number Badge */}
                <div
                  className="absolute left-2.5 z-10 w-7 h-7 rounded-full text-white font-mono font-black text-xs sm:text-sm flex items-center justify-center shadow-md border border-white/40"
                  style={{ backgroundColor: r.color }}
                >
                  {r.lane}
                </div>

                {/* Animated Running Horse with Jockey & Student Name */}
                <div
                  className="absolute flex items-center gap-2 will-change-transform z-30 transition-transform duration-75 ease-out"
                  style={{
                    transform: `translate3d(calc(36px + (100% - 170px) * ${r.progress / 100}), ${
                      isSpinning ? Math.sin(gallopPhaseRef.current + r.bobOffset) * 2.5 : 0
                    }px, 0)`,
                  }}
                >
                  {/* Dust particles when running */}
                  {isSpinning && (
                    <div className="absolute -left-3 bottom-1 flex gap-1 pointer-events-none">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-200/60 animate-ping" />
                      <span className="w-2 h-2 rounded-full bg-amber-300/40 animate-pulse" />
                    </div>
                  )}

                  {/* High Quality Animated Horse SVG */}
                  <AnimatedHorseSVG
                    color={r.color}
                    isGalloping={isSpinning}
                    phase={gallopPhaseRef.current + r.bobOffset}
                  />

                  {/* Student Name Card - BIGGER TEXT */}
                  <div
                    className={`px-3 py-1.5 rounded-xl shadow-md border text-xs sm:text-sm font-extrabold truncate max-w-[140px] sm:max-w-[200px] transition-all ${
                      isWinnerCrossing
                        ? 'bg-yellow-300 text-slate-950 border-yellow-100 scale-110 font-black shadow-lg animate-bounce'
                        : 'bg-white/95 text-slate-800 border-slate-200'
                    }`}
                  >
                    {r.student.name}
                  </div>
                </div>

                {/* Lane Dividing White Turf Marker */}
                <div className="w-full border-t border-dashed border-white/20 absolute top-1/2 pointer-events-none" />
              </div>
            );
          })}
        </div>

        {/* Bottom footer text */}
        <div className="text-center mt-2 text-amber-200/90 text-xs font-semibold shrink-0">
          🐎 Đua ngựa hoạt hình 60 FPS · Đường đua mở rộng toàn màn hình
        </div>
      </div>
    </div>
  );
};
