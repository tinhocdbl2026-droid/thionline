import React, { useEffect, useRef, useState } from 'react';
import { Student } from '../../types';
import { playDartHit } from '../../utils/soundEffects';

interface DartsModeProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

const RING_COLORS = [
  '#EF4444', '#10B981', '#3B82F6', '#F59E0B', '#8B5CF6',
  '#EC4899', '#06B6D4', '#F97316', '#6366F1', '#14B8A6'
];

export const DartsMode: React.FC<DartsModeProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const spinStartRef = useRef<number | null>(null);
  const targetWinnerRef = useRef<Student | null>(null);
  const targetAngleRef = useRef<number>(0);
  const hasHitRef = useRef(false);
  const [hitStudent, setHitStudent] = useState<Student | null>(null);

  // Set up target when spin starts
  useEffect(() => {
    if (isSpinning && availableStudents.length > 0) {
      hasHitRef.current = false;
      setHitStudent(null);
      spinStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * availableStudents.length);
      const winner = availableStudents[winnerIdx];
      targetWinnerRef.current = winner;

      const numSlices = availableStudents.length;
      const sliceAngle = (Math.PI * 2) / numSlices;
      targetAngleRef.current = winnerIdx * sliceAngle + sliceAngle / 2;
    }
  }, [isSpinning, availableStudents]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = (time: number) => {
      const width = canvas.width;
      const height = canvas.height;
      const cx = width / 2;
      const cy = height / 2;
      const boardRadius = Math.min(cx, cy) - 20;

      ctx.clearRect(0, 0, width, height);

      let shakeX = 0;
      let shakeY = 0;
      let dartScale = 1;
      let dartX = cx;
      let dartY = cy;
      let isDartVisible = false;

      if (isSpinning && spinStartRef.current && targetWinnerRef.current) {
        const elapsed = (time - spinStartRef.current) / 1000;
        const totalDur = duration;
        const flightTime = totalDur * 0.75;

        if (elapsed < flightTime) {
          // Dart is flying from bottom right towards the target slice on the dartboard
          isDartVisible = true;
          const progress = Math.min(1, elapsed / flightTime);
          const easeProgress = Math.pow(progress, 2.5); // Accelerate towards board

          const startX = width + 50;
          const startY = height + 80;

          // Target point on board
          const hitR = boardRadius * 0.65;
          const targetX = cx + Math.cos(targetAngleRef.current) * hitR;
          const targetY = cy + Math.sin(targetAngleRef.current) * hitR;

          dartX = startX + (targetX - startX) * easeProgress;
          dartY = startY + (targetY - startY) * easeProgress;
          // Scale shrinks from large (close to camera) to small (hitting board)
          dartScale = 2.4 - 1.4 * easeProgress;
        } else {
          // Dart has hit the board!
          isDartVisible = true;
          const hitR = boardRadius * 0.65;
          dartX = cx + Math.cos(targetAngleRef.current) * hitR;
          dartY = cy + Math.sin(targetAngleRef.current) * hitR;
          dartScale = 1.0;

          if (!hasHitRef.current) {
            hasHitRef.current = true;
            setHitStudent(targetWinnerRef.current);
            if (soundEnabled) {
              playDartHit(soundVolume);
            }
            setTimeout(() => {
              if (targetWinnerRef.current) {
                onSpinEnd(targetWinnerRef.current);
              }
            }, 600);
          }

          // Rattle / board shake for 300ms after impact
          const shakeElapsed = elapsed - flightTime;
          if (shakeElapsed < 0.35) {
            const decay = 1 - shakeElapsed / 0.35;
            shakeX = (Math.random() - 0.5) * 12 * decay;
            shakeY = (Math.random() - 0.5) * 12 * decay;
          }
        }
      }

      ctx.save();
      ctx.translate(shakeX, shakeY);

      // --- 1. DRAW DARTBOARD ---
      // Outer drop shadow
      ctx.save();
      ctx.shadowColor = 'rgba(0,0,0,0.2)';
      ctx.shadowBlur = 18;
      ctx.shadowOffsetY = 8;
      ctx.fillStyle = '#1E293B';
      ctx.beginPath();
      ctx.arc(cx, cy, boardRadius + 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Outer rim ring (wooden / wireframe)
      const rimGrad = ctx.createLinearGradient(cx - boardRadius, cy - boardRadius, cx + boardRadius, cy + boardRadius);
      rimGrad.addColorStop(0, '#78350F');
      rimGrad.addColorStop(0.5, '#B45309');
      rimGrad.addColorStop(1, '#451A03');
      ctx.fillStyle = rimGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, boardRadius + 14, 0, Math.PI * 2);
      ctx.fill();

      // Board wire outer circle
      ctx.strokeStyle = '#FEF08A';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(cx, cy, boardRadius + 2, 0, Math.PI * 2);
      ctx.stroke();

      // Slices for each student
      const numSlices = Math.max(1, availableStudents.length);
      const sliceAngle = (Math.PI * 2) / numSlices;

      for (let i = 0; i < numSlices; i++) {
        const student = availableStudents[i];
        const sStart = i * sliceAngle;
        const sEnd = (i + 1) * sliceAngle;
        const color = RING_COLORS[i % RING_COLORS.length];

        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, boardRadius, sStart, sEnd);
        ctx.closePath();
        ctx.fill();

        // Slice wire separator
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(sStart) * boardRadius, cy + Math.sin(sStart) * boardRadius);
        ctx.stroke();

        // Text (Name / Number) - ENLARGED FOR CLASSROOM PROJECTION
        ctx.save();
        const midAngle = sStart + sliceAngle / 2;
        ctx.translate(cx, cy);
        ctx.rotate(midAngle);
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#FFFFFF';
        ctx.shadowColor = 'rgba(0,0,0,0.85)';
        ctx.shadowBlur = 6;
        const fontSize = numSlices <= 10 ? 32 : numSlices <= 18 ? 26 : numSlices <= 30 ? 22 : 18;
        ctx.font = `900 ${fontSize}px "Be Vietnam Pro", sans-serif`;
        const rawText = student ? `${student.number}. ${student.name}` : `${i + 1}`;
        const maxLen = numSlices <= 16 ? 18 : 14;
        const text = rawText.length > maxLen ? rawText.slice(0, maxLen - 1) + '…' : rawText;
        ctx.fillText(text, boardRadius - 26, 0);
        ctx.restore();
      }

      // Inner multiplier wire rings
      [0.72, 0.45].forEach(rRatio => {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(cx, cy, boardRadius * rRatio, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Center Bullseye Rings
      ctx.fillStyle = '#10B981';
      ctx.beginPath();
      ctx.arc(cx, cy, 26, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(cx, cy, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // --- 2. DRAW DART IF IN FLIGHT OR HIT ---
      if (isDartVisible) {
        ctx.save();
        ctx.translate(dartX, dartY);
        ctx.scale(dartScale, dartScale);

        // Dart angle (pointing towards target)
        const angle = targetAngleRef.current + Math.PI;
        ctx.rotate(angle);

        // Dart tip
        ctx.fillStyle = '#94A3B8';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-8, -3);
        ctx.lineTo(-8, 3);
        ctx.closePath();
        ctx.fill();

        // Dart metal barrel
        const barrelGrad = ctx.createLinearGradient(-8, -4, -30, 4);
        barrelGrad.addColorStop(0, '#FEF08A');
        barrelGrad.addColorStop(0.5, '#F59E0B');
        barrelGrad.addColorStop(1, '#B45309');
        ctx.fillStyle = barrelGrad;
        ctx.fillRect(-28, -3.5, 20, 7);

        // Dart shaft
        ctx.fillStyle = '#1E293B';
        ctx.fillRect(-46, -2, 18, 4);

        // Dart flights (wings)
        ctx.fillStyle = '#EF4444';
        ctx.beginPath();
        ctx.moveTo(-44, 0);
        ctx.lineTo(-62, -14);
        ctx.lineTo(-56, 0);
        ctx.lineTo(-62, 14);
        ctx.closePath();
        ctx.fill();

        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.restore();
      }

      ctx.restore(); // restore shake

      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [availableStudents, isSpinning, duration, soundEnabled, soundVolume, onSpinEnd]);

  return (
    <div className="relative flex flex-col items-center justify-center w-full h-full select-none p-1 sm:p-2 overflow-hidden">
      <div className="relative w-full h-full max-w-[min(98%,calc(100vh-115px))] max-h-[calc(100vh-115px)] aspect-square flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={800}
          height={800}
          className="w-full h-full max-w-full max-h-full object-contain filter drop-shadow-2xl"
        />

        {isSpinning && !hitStudent && (
          <div className="absolute top-3 bg-red-600/95 text-white font-display text-base sm:text-lg px-6 py-2 rounded-full shadow-2xl border-2 border-red-200 backdrop-blur-md flex items-center gap-2.5 animate-bounce z-30 pointer-events-none">
            <span className="inline-block w-3.5 h-3.5 rounded-full bg-white animate-ping" />
            <span className="font-black tracking-wide drop-shadow">PHI TIÊU ĐANG PHÓNG TỚI BẢNG...</span>
          </div>
        )}

        {/* Subtle overlay pill at bottom */}
        <div className="absolute bottom-1 bg-slate-900/70 text-white font-medium text-[11px] sm:text-xs px-3.5 py-1 rounded-full backdrop-blur-xs border border-white/20 shadow-md pointer-events-none">
          🎯 Phi tiêu may mắn · {availableStudents.length} học sinh trên bảng điểm
        </div>
      </div>
    </div>
  );
};
