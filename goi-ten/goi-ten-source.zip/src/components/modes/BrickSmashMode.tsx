import React, { useEffect, useState, useRef } from 'react';
import { Student } from '../../types';
import { playBrickSmashSound } from '../../utils/soundEffects';

interface BrickSmashProps {
  availableStudents: Student[];
  isSpinning: boolean;
  duration: number;
  soundEnabled: boolean;
  soundVolume: number;
  onSpinEnd: (winner: Student) => void;
}

export const BrickSmashMode: React.FC<BrickSmashProps> = ({
  availableStudents,
  isSpinning,
  duration,
  soundEnabled,
  soundVolume,
  onSpinEnd,
}) => {
  const [smashedCount, setSmashedCount] = useState(0);
  const [winnerStudent, setWinnerStudent] = useState<Student | null>(null);
  const [hammerAngle, setHammerAngle] = useState(0);
  const totalBricks = 24; // 4 rows x 6 cols
  const spinStartRef = useRef<number | null>(null);
  const hasRevealedRef = useRef(false);

  useEffect(() => {
    if (isSpinning && availableStudents.length > 0) {
      setSmashedCount(0);
      hasRevealedRef.current = false;
      spinStartRef.current = performance.now();

      const winnerIdx = Math.floor(Math.random() * availableStudents.length);
      const winner = availableStudents[winnerIdx];
      setWinnerStudent(winner);
    }
  }, [isSpinning, availableStudents]);

  // Smooth smashing animation with hammer impacts
  useEffect(() => {
    if (!isSpinning || !winnerStudent) return;

    const intervalTime = (Math.max(1.5, duration) * 1000) / totalBricks;
    let count = 0;

    const interval = setInterval(() => {
      count++;
      setSmashedCount(count);
      // Swing hammer back and forth
      setHammerAngle(prev => (prev > 0 ? -35 : 45));

      if (soundEnabled && count % 3 === 0) {
        playBrickSmashSound(soundVolume * 0.4);
      }

      if (count >= totalBricks) {
        clearInterval(interval);
        if (!hasRevealedRef.current) {
          hasRevealedRef.current = true;
          if (soundEnabled) {
            playBrickSmashSound(soundVolume * 0.7);
          }
          setTimeout(() => {
            onSpinEnd(winnerStudent);
          }, 650);
        }
      }
    }, intervalTime);

    return () => clearInterval(interval);
  }, [isSpinning, duration, winnerStudent, soundEnabled, soundVolume, onSpinEnd]);

  const activeStudent = winnerStudent || availableStudents[0];

  return (
    <div className="flex flex-col items-center justify-center w-full h-full select-none max-w-4xl px-2 overflow-hidden">
      {/* Brick Wall Chamber */}
      <div className="relative w-[min(96%,calc((100vh-130px)*1.33))] h-[min(96%,calc(100vh-130px))] aspect-[4/3] bg-gradient-to-b from-amber-950 via-slate-900 to-amber-950 rounded-3xl p-4 shadow-2xl border-4 border-amber-600 flex items-center justify-center overflow-hidden">
        {/* Golden Hidden Chamber Behind Bricks */}
        <div className="absolute inset-4 rounded-2xl bg-gradient-to-tr from-amber-400 via-yellow-200 to-amber-300 flex flex-col items-center justify-center p-6 shadow-2xl text-center z-10 border-2 border-white/60">
          <span className="text-6xl mb-2 animate-bounce">🏆</span>
          <span className="text-xs sm:text-sm uppercase font-extrabold tracking-widest text-amber-950 mb-1">
            HỌC SINH ĐƯỢC CHỌN
          </span>
          <h3 className="font-display font-black text-4xl sm:text-6xl text-rose-600 drop-shadow-md truncate max-w-full">
            {activeStudent?.name}
          </h3>
          <span className="mt-4 bg-amber-950 text-white font-mono font-black text-base px-5 py-1.5 rounded-full shadow-lg">
            Số thứ tự: {activeStudent?.number}
          </span>
        </div>

        {/* 3D Beveled Brick Wall Overlay */}
        <div className="absolute inset-4 grid grid-cols-6 grid-rows-4 gap-1.5 z-20 pointer-events-none">
          {[...Array(totalBricks)].map((_, i) => {
            const isBroken = i < smashedCount;

            return (
              <div
                key={i}
                className={`rounded-md border border-amber-600/70 shadow-md transition-all duration-200 flex items-center justify-center relative overflow-hidden ${
                  isBroken
                    ? 'opacity-0 scale-50 rotate-12 pointer-events-none'
                    : 'bg-gradient-to-br from-amber-600 via-amber-700 to-amber-900 opacity-100 shadow-inner'
                }`}
              >
                {!isBroken && (
                  <>
                    <div className="w-full h-[1px] bg-amber-400/40 absolute top-0" />
                    <div className="w-[1px] h-full bg-amber-400/40 absolute left-0" />
                    <div className="w-full h-[1px] bg-amber-950/80 absolute bottom-0" />
                    <div className="w-[1px] h-full bg-amber-950/80 absolute right-0" />
                    <div className="w-full h-full flex items-center justify-center opacity-30 text-amber-200 text-xs font-mono font-bold">
                      {i + 1}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>

        {/* Swinging Golden Power Hammer during Smash */}
        {isSpinning && (
          <div
            className="absolute z-30 pointer-events-none transition-transform duration-100 ease-out"
            style={{
              top: '20%',
              right: '25%',
              transform: `rotate(${hammerAngle}deg) translate(-20px, -20px)`,
            }}
          >
            <svg viewBox="0 0 60 80" className="w-20 h-24 drop-shadow-2xl">
              {/* Wooden Handle */}
              <rect x="26" y="24" width="8" height="52" rx="3" fill="#78350F" stroke="#FDE68A" strokeWidth="1" />
              {/* Golden Hammer Head */}
              <rect x="10" y="8" width="40" height="20" rx="4" fill="#F59E0B" stroke="#FEF08A" strokeWidth="2" />
              <rect x="16" y="12" width="28" height="12" rx="2" fill="#FDE047" />
            </svg>
          </div>
        )}
      </div>

      <div className="text-center mt-3 text-slate-500 text-xs sm:text-sm font-medium">
        Đập gạch 60 FPS · Búa thần đập vỡ từng viên gạch để hé lộ bạn học sinh may mắn!
      </div>
    </div>
  );
};
