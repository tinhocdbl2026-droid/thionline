export interface Student {
  id: string;
  name: string;
  number: number;
  color?: string;
  calledCount?: number;
  lastCalledAt?: number;
}

export type GameMode =
  | 'cage'
  | 'wheel'
  | 'box'
  | 'balloon'
  | 'number'
  | 'darts'
  | 'horse_race'
  | 'rocket'
  | 'fishing'
  | 'balloon_pop'
  | 'ufo'
  | 'car_race'
  | 'brick_smash'
  | 'penalty_kick';

export interface SchoolClass {
  id: string;
  name: string;
  createdAt: number;
  students: Student[];
  calledIds: string[];
  history: CallHistoryItem[];
}

export interface AppSettings {
  className: string;
  teacherName: string;
  duration: number; // in seconds (3, 5, 10)
  soundEnabled: boolean;
  soundVolume: number; // 0 to 1
  speechEnabled: boolean;
  confettiEnabled: boolean;
  noRepeat: boolean;
}

export interface CallHistoryItem {
  id: string;
  studentId: string;
  studentName: string;
  studentNumber: number;
  calledAt: number;
  mode: GameMode;
  order: number;
}

export const DEFAULT_STUDENTS: Omit<Student, 'id' | 'number'>[] = Array.from({ length: 20 }, (_, i) => ({ name: `Học sinh mẫu ${i + 1}` }));

export const BALL_COLORS = [
  '#EF4444', // Red
  '#F97316', // Orange
  '#F59E0B', // Amber
  '#10B981', // Emerald
  '#06B6D4', // Cyan
  '#3B82F6', // Blue
  '#6366F1', // Indigo
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#14B8A6', // Teal
];
