import { SchoolClass, Student, DEFAULT_STUDENTS, BALL_COLORS, CallHistoryItem } from '../types';

const DB_NAME = 'GoiTen20261006DB';
const DB_VERSION = 1;
const STORE_CLASSES = 'classes';
const STORE_META = 'metadata';

const LOCAL_STORAGE_KEYS = {
  CLASSES: 'goi_ten_20261006_classes_v2',
  ACTIVE_CLASS_ID: 'goi_ten_20261006_active_class_v2',
  LEGACY_STUDENTS: 'goi_ten_20261006_students_v1',
  LEGACY_CALLED: 'goi_ten_20261006_called_ids_v1',
  LEGACY_HISTORY: 'goi_ten_20261006_history_v1',
  LEGACY_SETTINGS: 'goi_ten_20261006_settings_v1',
};

// Default starter classes if completely new
export const DEFAULT_STARTER_CLASSES: SchoolClass[] = [
  {
    id: 'class_3_1',
    name: 'Lớp 3/1',
    createdAt: Date.now() - 3600000 * 24,
    students: DEFAULT_STUDENTS.slice(0, 20).map((st, idx) => ({
      id: 'st_31_' + (idx + 1),
      name: st.name,
      number: idx + 1,
      color: BALL_COLORS[idx % BALL_COLORS.length],
      calledCount: 0,
    })),
    calledIds: [],
    history: [],
  },
  {
    id: 'class_3_2',
    name: 'Lớp 3/2',
    createdAt: Date.now() - 3600000 * 12,
    students: Array.from({ length: 24 }, (_, i) => `Học sinh mẫu ${i + 1}`).map((name, idx) => ({
      id: 'st_32_' + (idx + 1),
      name,
      number: idx + 1,
      color: BALL_COLORS[idx % BALL_COLORS.length],
      calledCount: 0,
    })),
    calledIds: [],
    history: [],
  },
  {
    id: 'class_4_1',
    name: 'Lớp 4/1',
    createdAt: Date.now() - 3600000 * 6,
    students: Array.from({ length: 18 }, (_, i) => `Học sinh mẫu ${i + 1}`).map((name, idx) => ({
      id: 'st_41_' + (idx + 1),
      name,
      number: idx + 1,
      color: BALL_COLORS[idx % BALL_COLORS.length],
      calledCount: 0,
    })),
    calledIds: [],
    history: [],
  },
];

// Open IndexedDB promise
function openIndexedDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = event => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_CLASSES)) {
        db.createObjectStore(STORE_CLASSES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Synchronous initial load with localStorage + Legacy migration
export function getInitialClasses(): { classes: SchoolClass[]; activeClassId: string } {
  try {
    // 1. Check if we already have multi-class data in localStorage
    const savedClasses = localStorage.getItem(LOCAL_STORAGE_KEYS.CLASSES);
    if (savedClasses) {
      const parsed: SchoolClass[] = JSON.parse(savedClasses);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const savedActiveId = localStorage.getItem(LOCAL_STORAGE_KEYS.ACTIVE_CLASS_ID);
        const activeId = parsed.find(c => c.id === savedActiveId)?.id || parsed[0].id;
        return { classes: parsed, activeClassId: activeId };
      }
    }

    // 2. Legacy Migration: check if single-class data exists
    const legacyStudentsStr = localStorage.getItem(LOCAL_STORAGE_KEYS.LEGACY_STUDENTS);
    if (legacyStudentsStr) {
      try {
        const legacyStudents: Student[] = JSON.parse(legacyStudentsStr);
        if (Array.isArray(legacyStudents) && legacyStudents.length > 0) {
          let legacyClassName = 'Lớp 3A';
          try {
            const legacySettings = localStorage.getItem(LOCAL_STORAGE_KEYS.LEGACY_SETTINGS);
            if (legacySettings) {
              const parsedSettings = JSON.parse(legacySettings);
              if (parsedSettings.className) legacyClassName = parsedSettings.className;
            }
          } catch {
            // ignore
          }

          let legacyCalled: string[] = [];
          try {
            const calledStr = localStorage.getItem(LOCAL_STORAGE_KEYS.LEGACY_CALLED);
            if (calledStr) legacyCalled = JSON.parse(calledStr);
          } catch {
            // ignore
          }

          let legacyHistory: CallHistoryItem[] = [];
          try {
            const historyStr = localStorage.getItem(LOCAL_STORAGE_KEYS.LEGACY_HISTORY);
            if (historyStr) legacyHistory = JSON.parse(historyStr);
          } catch {
            // ignore
          }

          const migratedClass: SchoolClass = {
            id: 'class_migrated_' + Date.now(),
            name: legacyClassName,
            createdAt: Date.now(),
            students: legacyStudents,
            calledIds: legacyCalled,
            history: legacyHistory,
          };

          const classes = [migratedClass, ...DEFAULT_STARTER_CLASSES.slice(1)];
          localStorage.setItem(LOCAL_STORAGE_KEYS.CLASSES, JSON.stringify(classes));
          localStorage.setItem(LOCAL_STORAGE_KEYS.ACTIVE_CLASS_ID, migratedClass.id);
          return { classes, activeClassId: migratedClass.id };
        }
      } catch (err) {
        console.error('Migration failed:', err);
      }
    }
  } catch (err) {
    console.error('Failed reading localStorage classes:', err);
  }

  // 3. Fallback to default starter classes
  const classes = DEFAULT_STARTER_CLASSES;
  try {
    localStorage.setItem(LOCAL_STORAGE_KEYS.CLASSES, JSON.stringify(classes));
    localStorage.setItem(LOCAL_STORAGE_KEYS.ACTIVE_CLASS_ID, classes[0].id);
  } catch {
    // ignore
  }
  return { classes, activeClassId: classes[0].id };
}

// Persist classes to both IndexedDB and localStorage
export async function persistClasses(classes: SchoolClass[], activeClassId?: string): Promise<void> {
  // 1. Sync to localStorage immediately
  try {
    localStorage.setItem(LOCAL_STORAGE_KEYS.CLASSES, JSON.stringify(classes));
    if (activeClassId) {
      localStorage.setItem(LOCAL_STORAGE_KEYS.ACTIVE_CLASS_ID, activeClassId);
    }
  } catch (err) {
    console.warn('LocalStorage save error:', err);
  }

  // 2. Persist to IndexedDB in background
  try {
    const db = await openIndexedDB();
    const tx = db.transaction([STORE_CLASSES, STORE_META], 'readwrite');
    const classStore = tx.objectStore(STORE_CLASSES);
    const metaStore = tx.objectStore(STORE_META);

    // Clear old classes and insert updated ones
    classStore.clear();
    classes.forEach(c => {
      classStore.put(c);
    });

    if (activeClassId) {
      metaStore.put({ key: 'activeClassId', value: activeClassId });
    }
    metaStore.put({ key: 'lastUpdated', value: Date.now() });

    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IndexedDB save error (fallback active via localStorage):', err);
  }
}

// Background sync from IndexedDB on startup
export async function syncFromIndexedDB(): Promise<{ classes: SchoolClass[]; activeClassId: string } | null> {
  try {
    const db = await openIndexedDB();
    const tx = db.transaction([STORE_CLASSES, STORE_META], 'readonly');
    const classStore = tx.objectStore(STORE_CLASSES);
    const metaStore = tx.objectStore(STORE_META);

    const classesReq = classStore.getAll();
    const activeReq = metaStore.get('activeClassId');

    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });

    const classes: SchoolClass[] = classesReq.result || [];
    if (classes.length > 0) {
      const activeClassId = activeReq.result?.value || classes[0].id;
      // Also update localStorage cache
      localStorage.setItem(LOCAL_STORAGE_KEYS.CLASSES, JSON.stringify(classes));
      localStorage.setItem(LOCAL_STORAGE_KEYS.ACTIVE_CLASS_ID, activeClassId);
      return { classes, activeClassId };
    }
  } catch {
    // Ignore IndexedDB failures, localStorage is the active cache
  }
  return null;
}
