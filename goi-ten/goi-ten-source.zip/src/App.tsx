import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Student,
  GameMode,
  AppSettings,
  CallHistoryItem,
  SchoolClass,
  DEFAULT_STUDENTS,
  BALL_COLORS,
} from './types';
import { BingoCageMode } from './components/modes/BingoCageMode';
import { LuckyWheelMode } from './components/modes/LuckyWheelMode';
import { MysteryBoxMode } from './components/modes/MysteryBoxMode';
import { FloatingBalloonsMode } from './components/modes/FloatingBalloonsMode';
import { DigitalSlotMode } from './components/modes/DigitalSlotMode';
import { DartsMode } from './components/modes/DartsMode';
import { HorseRaceMode } from './components/modes/HorseRaceMode';
import { RocketLaunchMode } from './components/modes/RocketLaunchMode';
import { FishingPondMode } from './components/modes/FishingPondMode';
import { BalloonPopMode } from './components/modes/BalloonPopMode';
import { UfoBeamMode } from './components/modes/UfoBeamMode';
import { CarRaceMode } from './components/modes/CarRaceMode';
import { BrickSmashMode } from './components/modes/BrickSmashMode';
import { PenaltyKickMode } from './components/modes/PenaltyKickMode';
import { WinnerModal } from './components/WinnerModal';
import { StudentManagerModal } from './components/StudentManagerModal';
import { ClassManagerModal } from './components/ClassManagerModal';
import { CallHistoryModal } from './components/CallHistoryModal';
import { SettingsModal } from './components/SettingsModal';
import { GameSelectorModal, ALL_GAMES } from './components/GameSelectorModal';
import { CageAudioController, playButtonClick } from './utils/soundEffects';
import { getInitialClasses, persistClasses, syncFromIndexedDB } from './utils/classStorage';
import {
  Maximize,
  Minimize,
  Settings as SettingsIcon,
  Users,
  History,
  RotateCcw,
  Volume2,
  VolumeX,
  Play,
  CheckCircle2,
  GraduationCap,
  Gamepad2,
  Clock,
  Minus,
  Plus,
  ChevronDown,
} from 'lucide-react';

const STORAGE_KEYS = {
  STUDENTS: 'goi_ten_20261006_students_v1',
  SETTINGS: 'goi_ten_20261006_settings_v1',
  HISTORY: 'goi_ten_20261006_history_v1',
  CALLED_IDS: 'goi_ten_20261006_called_ids_v1',
};

const DEFAULT_SETTINGS: AppSettings = {
  className: 'Lớp 3A',
  teacherName: '',
  duration: 4, // seconds
  soundEnabled: true,
  soundVolume: 0.7,
  speechEnabled: true,
  confettiEnabled: true,
  noRepeat: true,
};

export default function App() {
  // 1. Multi-Class State & Persistent Storage (IndexedDB + localStorage)
  const [{ classes, activeClassId }, setClassState] = useState(() => getInitialClasses());
  const [isClassManagerOpen, setIsClassManagerOpen] = useState(false);
  const [isClassDropdownOpen, setIsClassDropdownOpen] = useState(false);

  // Active class derivation
  const currentClass: SchoolClass = useMemo(() => {
    return classes.find(c => c.id === activeClassId) || classes[0] || {
      id: 'default',
      name: 'Lớp học',
      createdAt: Date.now(),
      students: [],
      calledIds: [],
      history: [],
    };
  }, [classes, activeClassId]);

  const students = currentClass.students || [];
  const calledIds = currentClass.calledIds || [];
  const history = currentClass.history || [];

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_SETTINGS;
  });

  // Sync with IndexedDB in background on initial mount
  useEffect(() => {
    syncFromIndexedDB().then(res => {
      if (res && res.classes.length > 0) {
        setClassState(res);
        const active = res.classes.find(c => c.id === res.activeClassId);
        if (active) {
          setSettings(s => ({ ...s, className: active.name }));
        }
      }
    });
  }, []);

  // Save changes to storage
  useEffect(() => {
    persistClasses(classes, activeClassId);
  }, [classes, activeClassId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  // Keep settings.className in sync with current active class
  useEffect(() => {
    if (currentClass && currentClass.name && settings.className !== currentClass.name) {
      setSettings(s => ({ ...s, className: currentClass.name }));
    }
  }, [currentClass]);

  // Class Management Handlers
  const handleSelectClass = (classId: string) => {
    playButtonClick(settings.soundVolume);
    setClassState(prev => {
      const target = prev.classes.find(c => c.id === classId);
      if (target) {
        setSettings(s => ({ ...s, className: target.name }));
        return { ...prev, activeClassId: classId };
      }
      return prev;
    });
    setIsClassDropdownOpen(false);
  };

  const handleAddClass = (name: string, newStudents: Student[]) => {
    const newClass: SchoolClass = {
      id: 'class_' + Date.now(),
      name,
      createdAt: Date.now(),
      students: newStudents,
      calledIds: [],
      history: [],
    };
    setClassState(prev => ({
      classes: [...prev.classes, newClass],
      activeClassId: newClass.id,
    }));
    setSettings(s => ({ ...s, className: name }));
  };

  const handleRenameClass = (classId: string, newName: string) => {
    setClassState(prev => ({
      ...prev,
      classes: prev.classes.map(c => (c.id === classId ? { ...c, name: newName } : c)),
    }));
    if (classId === activeClassId) {
      setSettings(s => ({ ...s, className: newName }));
    }
  };

  const handleDeleteClass = (classId: string) => {
    setClassState(prev => {
      if (prev.classes.length <= 1) return prev;
      const filtered = prev.classes.filter(c => c.id !== classId);
      let nextActiveId = prev.activeClassId;
      if (prev.activeClassId === classId) {
        nextActiveId = filtered[0].id;
        setSettings(s => ({ ...s, className: filtered[0].name }));
      }
      return { classes: filtered, activeClassId: nextActiveId };
    });
  };

  const handleResetClassCalled = (classId: string) => {
    playButtonClick(settings.soundVolume);
    setClassState(prev => ({
      ...prev,
      classes: prev.classes.map(c =>
        c.id === classId
          ? {
              ...c,
              calledIds: [],
              students: c.students.map(s => ({ ...s, calledCount: 0 })),
            }
          : c
      ),
    }));
  };

  const handleResetCalledStatus = () => {
    handleResetClassCalled(activeClassId);
  };

  const handleClearHistory = () => {
    playButtonClick(settings.soundVolume);
    setClassState(prev => ({
      ...prev,
      classes: prev.classes.map(c => (c.id === prev.activeClassId ? { ...c, history: [] } : c)),
    }));
  };

  const handleUpdateStudents = (newStudents: Student[]) => {
    setClassState(prev => ({
      ...prev,
      classes: prev.classes.map(c =>
        c.id === prev.activeClassId ? { ...c, students: newStudents } : c
      ),
    }));
  };

  // 2. Game Mode & Spin State
  const [currentMode, setCurrentMode] = useState<GameMode>('cage');
  const [isSpinning, setIsSpinning] = useState(false);
  const [winnerModalOpen, setWinnerModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  // 3. Modals
  const [isStudentManagerOpen, setIsStudentManagerOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isGameSelectorOpen, setIsGameSelectorOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Cage Audio controller instance
  const cageAudioRef = useRef<CageAudioController | null>(null);
  useEffect(() => {
    cageAudioRef.current = new CageAudioController(settings.soundVolume);
  }, []);

  useEffect(() => {
    if (cageAudioRef.current) {
      cageAudioRef.current.setVolume(settings.soundVolume);
    }
  }, [settings.soundVolume]);

  // 4. Available Pool Computation
  const availableStudents = useMemo(() => {
    if (!settings.noRepeat) return students;
    return students.filter(s => !calledIds.includes(s.id));
  }, [students, calledIds, settings.noRepeat]);

  // Current Game Info
  const currentGameInfo = useMemo(() => {
    return ALL_GAMES.find(g => g.id === currentMode) || ALL_GAMES[0];
  }, [currentMode]);

  // Track Fullscreen state changes
  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleFullscreen = () => {
    playButtonClick(settings.soundVolume);
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.warn('Fullscreen request failed:', err);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(console.warn);
      }
    }
  };

  // 5. Spin Handler
  const handleStartSpin = () => {
    if (isSpinning) return;
    if (availableStudents.length === 0) {
      return;
    }

    playButtonClick(settings.soundVolume);
    setIsSpinning(true);
    setWinnerModalOpen(false);

    // If cage mode, start cage continuous mechanical audio
    if (currentMode === 'cage' && settings.soundEnabled && cageAudioRef.current) {
      cageAudioRef.current.startSpinning();
    }
  };

  // 6. Spin Finish Callback from Mode Component
  const handleSpinEnd = (winner: Student) => {
    setIsSpinning(false);
    if (cageAudioRef.current) {
      cageAudioRef.current.stopSpinning();
    }

    setSelectedStudent(winner);
    setWinnerModalOpen(true);

    const historyItem: CallHistoryItem = {
      id: 'hist_' + Date.now(),
      studentId: winner.id,
      studentName: winner.name,
      studentNumber: winner.number,
      calledAt: Date.now(),
      mode: currentMode,
      order: history.length + 1,
    };

    // Update active class: calledIds, history, calledCount
    setClassState(prev => {
      const updatedClasses = prev.classes.map(c => {
        if (c.id !== prev.activeClassId) return c;
        const newCalledIds = c.calledIds.includes(winner.id)
          ? c.calledIds
          : [...c.calledIds, winner.id];
        const newHistory = [historyItem, ...(c.history || [])];
        const newStudents = c.students.map(s =>
          s.id === winner.id
            ? { ...s, calledCount: (s.calledCount || 0) + 1, lastCalledAt: Date.now() }
            : s
        );
        return {
          ...c,
          calledIds: newCalledIds,
          history: newHistory,
          students: newStudents,
        };
      });
      return { ...prev, classes: updatedClasses };
    });
  };

  const calledCount = students.length - availableStudents.length;
  const progressPercent = students.length > 0 ? Math.round((calledCount / students.length) * 100) : 0;

  return (
    <div className="h-screen w-screen overflow-hidden bg-gradient-to-br from-amber-50/70 via-orange-50/50 to-yellow-50/70 text-slate-800 flex flex-col select-none selection:bg-amber-200">
      {/* ===== TOP BAR (55–60px) ===== */}
      <header className="h-14 shrink-0 bg-white/95 backdrop-blur-md border-b border-amber-200/90 shadow-xs px-3 sm:px-5 flex items-center justify-between z-30">
        {/* Brand & Class Selector Dropdown */}
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center font-display text-lg sm:text-xl shadow-xs border border-amber-300 shrink-0">
            {currentGameInfo.icon}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h1 className="font-display font-black text-xs sm:text-sm md:text-base text-amber-950 tracking-tight leading-tight truncate">
                LỒNG CẦU GỌI TÊN
              </h1>

              {/* Class Dropdown Selector */}
              <div className="relative">
                <button
                  onClick={() => setIsClassDropdownOpen(!isClassDropdownOpen)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-950 bg-amber-100 hover:bg-amber-200/90 px-2.5 py-1 rounded-xl border border-amber-300/80 shadow-2xs transition-all cursor-pointer"
                  title="Bấm để chọn lớp khác hoặc quản lý lớp"
                >
                  <GraduationCap className="w-3.5 h-3.5 text-amber-700" />
                  <span className="font-black max-w-[80px] sm:max-w-[130px] truncate">{currentClass.name}</span>
                  <span className="text-[10px] font-black text-amber-800 bg-amber-200/80 px-1.5 py-0.2 rounded-full">
                    {students.length} HS
                  </span>
                  <ChevronDown className="w-3 h-3 text-amber-700" />
                </button>

                {/* Dropdown Menu */}
                {isClassDropdownOpen && (
                  <div className="absolute top-full left-0 mt-1.5 w-60 bg-white rounded-2xl shadow-xl border border-amber-200 p-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                      Chọn lớp giảng dạy:
                    </div>
                    <div className="max-h-52 overflow-y-auto space-y-1">
                      {classes.map(c => (
                        <button
                          key={c.id}
                          onClick={() => handleSelectClass(c.id)}
                          className={`w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between transition-colors cursor-pointer ${
                            c.id === activeClassId
                              ? 'bg-amber-500 text-white shadow-xs'
                              : 'hover:bg-amber-50 text-slate-800'
                          }`}
                        >
                          <span className="truncate">{c.name}</span>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full ${
                              c.id === activeClassId
                                ? 'bg-amber-600 text-white font-black'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {c.students.length} HS
                          </span>
                        </button>
                      ))}
                    </div>
                    <div className="border-t border-slate-100 mt-1.5 pt-1.5 space-y-1">
                      <button
                        onClick={() => {
                          setIsClassDropdownOpen(false);
                          setIsClassManagerOpen(true);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-bold text-amber-700 hover:bg-amber-50 flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Thêm lớp mới</span>
                      </button>
                      <button
                        onClick={() => {
                          setIsClassDropdownOpen(false);
                          setIsClassManagerOpen(true);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <SettingsIcon className="w-3.5 h-3.5 text-slate-500" />
                        <span>Quản lý danh sách lớp</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-amber-800/80 leading-none mt-0.5 truncate">
              {settings.teacherName && (
                <>
                  <span className="truncate">GV: {settings.teacherName}</span>
                  <span>·</span>
                </>
              )}
              <span className="font-semibold">{students.length} học sinh</span>
              <span>·</span>
              <span className="text-amber-700 font-bold truncate">{currentGameInfo.label}</span>
            </div>
          </div>
        </div>

        {/* Action Tools Header */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Quick Speech Toggle */}
          <button
            onClick={() => {
              playButtonClick(settings.soundVolume);
              setSettings(prev => ({ ...prev, speechEnabled: !prev.speechEnabled }));
            }}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1 cursor-pointer ${
              settings.speechEnabled
                ? 'bg-emerald-50 border-emerald-300 text-emerald-700 shadow-2xs'
                : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
            }`}
            title={settings.speechEnabled ? 'Giọng đọc tên: Đang bật' : 'Giọng đọc tên: Đang tắt'}
          >
            {settings.speechEnabled ? <Volume2 className="w-3.5 h-3.5 text-emerald-600" /> : <VolumeX className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">Đọc tên</span>
          </button>

          {/* History Button */}
          <button
            onClick={() => {
              playButtonClick(settings.soundVolume);
              setIsHistoryOpen(true);
            }}
            className="relative px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white hover:bg-amber-50/80 border border-slate-200 text-slate-700 transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
            title="Xem lịch sử học sinh đã gọi"
          >
            <History className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">Lịch sử</span>
            {history.length > 0 && (
              <span className="w-4.5 h-4.5 rounded-full bg-amber-500 text-white font-bold text-[10px] flex items-center justify-center">
                {history.length}
              </span>
            )}
          </button>

          {/* Class Manager Button */}
          <button
            onClick={() => {
              playButtonClick(settings.soundVolume);
              setIsClassManagerOpen(true);
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-amber-100/90 hover:bg-amber-200 text-amber-900 border border-amber-300 transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer"
            title="Quản lý danh sách các lớp học (Thêm, xóa, đổi tên lớp)"
          >
            <GraduationCap className="w-3.5 h-3.5 text-amber-700" />
            <span className="hidden sm:inline">Quản lý lớp ({classes.length})</span>
          </button>

          {/* Student Manager Button */}
          <button
            onClick={() => {
              playButtonClick(settings.soundVolume);
              setIsStudentManagerOpen(true);
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white hover:bg-amber-50/80 border border-slate-200 text-slate-700 transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
            title="Quản lý danh sách học sinh lớp đang chọn"
          >
            <Users className="w-3.5 h-3.5 text-sky-600" />
            <span className="hidden sm:inline">DS Học sinh ({students.length})</span>
          </button>

          {/* Settings Button */}
          <button
            onClick={() => {
              playButtonClick(settings.soundVolume);
              setIsSettingsOpen(true);
            }}
            className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-white hover:bg-amber-50/80 border border-slate-200 text-slate-700 transition-colors flex items-center gap-1 shadow-2xs cursor-pointer"
            title="Cài đặt thông số"
          >
            <SettingsIcon className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Cài đặt</span>
          </button>

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
            title="Phóng to toàn màn hình máy chiếu"
          >
            {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
            <span className="hidden md:inline">Toàn màn hình</span>
          </button>
        </div>
      </header>

      {/* ===== 2-COLUMN MAIN BODY (FITS 1 SCREEN) ===== */}
      <main className="flex-1 min-h-0 flex flex-col lg:flex-row p-1.5 sm:p-2 gap-1.5 sm:gap-2 overflow-hidden">
        {/* LEFT COLUMN: GAME ARENA (~74% width on desktop) */}
        <section className="flex-1 lg:flex-[7.4] xl:flex-[7.6] min-w-0 min-h-0 flex flex-col bg-white/80 backdrop-blur-md rounded-2xl border border-amber-200/90 shadow-xs overflow-hidden">
          {/* Quick Game Mode Bar */}
          <div className="h-10 shrink-0 px-2 sm:px-3 border-b border-amber-100 bg-amber-50/60 flex items-center justify-between gap-1 overflow-x-auto">
            <div className="flex items-center gap-1 overflow-x-auto py-0.5 scrollbar-none">
              {[
                { id: 'cage', label: 'Lồng cầu', icon: '🎱' },
                { id: 'wheel', label: 'Vòng quay', icon: '🎡' },
                { id: 'darts', label: 'Phi tiêu', icon: '🎯' },
                { id: 'horse_race', label: 'Đua ngựa', icon: '🐎' },
                { id: 'rocket', label: 'Tên lửa', icon: '🚀' },
                { id: 'fishing', label: 'Câu cá', icon: '🎣' },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (isSpinning) return;
                    playButtonClick(settings.soundVolume);
                    setCurrentMode(tab.id as GameMode);
                  }}
                  disabled={isSpinning}
                  className={`px-2.5 sm:px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1 cursor-pointer ${
                    currentMode === tab.id
                      ? 'bg-amber-500 text-white shadow-xs scale-102'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-amber-100/50'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}

              {/* Show current game badge if outside top 6 */}
              {![
                'cage',
                'wheel',
                'darts',
                'horse_race',
                'rocket',
                'fishing',
              ].includes(currentMode) && (
                <button className="px-2.5 sm:px-3 py-1 rounded-xl text-xs font-bold bg-amber-500 text-white shadow-xs flex items-center gap-1 scale-102">
                  <span>{currentGameInfo.icon}</span>
                  <span>{currentGameInfo.label}</span>
                </button>
              )}
            </div>

            {/* "🎮 Kho trò chơi (14)" button */}
            <button
              onClick={() => {
                if (isSpinning) return;
                playButtonClick(settings.soundVolume);
                setIsGameSelectorOpen(true);
              }}
              disabled={isSpinning}
              className="px-2.5 sm:px-3 py-1 rounded-xl text-xs font-black bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white shadow-2xs transition-all flex items-center gap-1 whitespace-nowrap shrink-0 cursor-pointer hover:scale-102"
              title="Mở kho tất cả 14 trò chơi gọi tên học sinh"
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>Kho trò chơi ({ALL_GAMES.length})</span>
            </button>
          </div>

          {/* Interactive Game Stage / Play Area (Maximized bounds for classroom) */}
          <div className="game-stage play-area flex-1 min-h-0 relative flex items-center justify-center p-1 sm:p-2 overflow-hidden w-full h-full">
            {students.length === 0 ? (
              <div className="bg-white/95 p-6 rounded-3xl border-2 border-dashed border-amber-300 text-center max-w-sm shadow-xs">
                <Users className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                <h3 className="font-display font-bold text-lg text-slate-800 mb-1">
                  Danh sách học sinh đang trống
                </h3>
                <p className="text-xs text-slate-500 mb-3">
                  Vui lòng thêm danh sách học sinh để bắt đầu gọi tên.
                </p>
                <button
                  onClick={() => setIsStudentManagerOpen(true)}
                  className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                >
                  + Thêm danh sách học sinh
                </button>
              </div>
            ) : (
              <>
                {currentMode === 'cage' && (
                  <BingoCageMode
                    students={students}
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    selectedStudent={selectedStudent}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'wheel' && (
                  <LuckyWheelMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'box' && (
                  <MysteryBoxMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'balloon' && (
                  <FloatingBalloonsMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'number' && (
                  <DigitalSlotMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'darts' && (
                  <DartsMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'horse_race' && (
                  <HorseRaceMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'rocket' && (
                  <RocketLaunchMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'fishing' && (
                  <FishingPondMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'balloon_pop' && (
                  <BalloonPopMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'ufo' && (
                  <UfoBeamMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'car_race' && (
                  <CarRaceMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'brick_smash' && (
                  <BrickSmashMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}

                {currentMode === 'penalty_kick' && (
                  <PenaltyKickMode
                    availableStudents={availableStudents}
                    isSpinning={isSpinning}
                    duration={settings.duration}
                    soundEnabled={settings.soundEnabled}
                    soundVolume={settings.soundVolume}
                    onSpinEnd={handleSpinEnd}
                  />
                )}
              </>
            )}
          </div>
        </section>

        {/* RIGHT COLUMN: CONTROL PANEL (~26% width on desktop) */}
        <aside className="w-full lg:w-[290px] xl:w-[320px] shrink-0 min-h-0 flex flex-col bg-white/95 backdrop-blur-md rounded-2xl border border-amber-200/90 shadow-xs p-2.5 gap-2 overflow-hidden">
          {/* 1. BIG LAUNCH / SPIN BUTTON */}
          <button
            onClick={handleStartSpin}
            disabled={isSpinning || availableStudents.length === 0}
            className={`w-full py-3 sm:py-3.5 px-4 rounded-2xl font-display text-lg sm:text-xl font-black text-white shadow-lg transition-all transform flex items-center justify-center gap-2 select-none shrink-0 cursor-pointer ${
              isSpinning
                ? 'bg-amber-400 opacity-90 cursor-not-allowed scale-98'
                : availableStudents.length === 0
                ? 'bg-slate-300 cursor-not-allowed shadow-none'
                : 'bg-gradient-to-r from-rose-500 via-amber-500 to-orange-500 hover:from-rose-600 hover:via-amber-600 hover:to-orange-600 hover:scale-[1.02] active:scale-98 hover:shadow-xl border-2 border-yellow-200 animate-pulse'
            }`}
          >
            {isSpinning ? (
              <>
                <span className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                <span className="tracking-wide">ĐANG CHỌN...</span>
              </>
            ) : availableStudents.length === 0 ? (
              <span className="text-sm">ĐÃ GỌI HẾT HỌC SINH</span>
            ) : (
              <>
                <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-white stroke-none" />
                <span className="tracking-wide">{currentGameInfo.buttonLabel}</span>
              </>
            )}
          </button>

          {/* 2. QUICK DURATION CONTROLLER */}
          <div className="bg-amber-50/60 rounded-xl border border-amber-200/70 p-2 sm:p-2.5 flex flex-col gap-1.5 shrink-0">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-700 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                Thời gian chọn:
              </span>
              <span className="font-mono font-extrabold text-amber-700 text-sm">
                {settings.duration}s
              </span>
            </div>

            <div className="flex items-center justify-between gap-1.5">
              {/* Stepper - / + */}
              <div className="flex items-center bg-white rounded-lg p-0.5 border border-slate-200 shadow-2xs">
                <button
                  onClick={() => {
                    playButtonClick(settings.soundVolume);
                    setSettings(prev => ({ ...prev, duration: Math.max(2, prev.duration - 1) }));
                  }}
                  disabled={isSpinning || settings.duration <= 2}
                  className="w-6 h-6 rounded-md bg-slate-100 hover:bg-amber-100 text-slate-700 font-bold flex items-center justify-center disabled:opacity-30 transition-colors cursor-pointer"
                  title="Giảm 1 giây"
                >
                  <Minus className="w-3 h-3" />
                </button>
                <span className="w-7 text-center font-bold text-xs font-mono text-slate-800">
                  {settings.duration}s
                </span>
                <button
                  onClick={() => {
                    playButtonClick(settings.soundVolume);
                    setSettings(prev => ({ ...prev, duration: Math.min(25, prev.duration + 1) }));
                  }}
                  disabled={isSpinning || settings.duration >= 25}
                  className="w-6 h-6 rounded-md bg-slate-100 hover:bg-amber-100 text-slate-700 font-bold flex items-center justify-center disabled:opacity-30 transition-colors cursor-pointer"
                  title="Tăng 1 giây"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </div>

              {/* Preset Buttons */}
              <div className="flex items-center gap-1">
                {[
                  { sec: 3, label: '3s' },
                  { sec: 5, label: '5s' },
                  { sec: 10, label: '10s' },
                  { sec: 15, label: '15s' },
                ].map(({ sec, label }) => (
                  <button
                    key={sec}
                    onClick={() => {
                      playButtonClick(settings.soundVolume);
                      setSettings(prev => ({ ...prev, duration: sec }));
                    }}
                    disabled={isSpinning}
                    className={`px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      settings.duration === sec
                        ? 'bg-amber-500 text-white shadow-2xs'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-amber-50 hover:text-amber-800'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 3. CALL STATUS & ROUND RULES */}
          <div className="bg-slate-50/90 rounded-xl border border-slate-200/70 p-2 sm:p-2.5 flex flex-col gap-1.5 shrink-0">
            {/* No Repeat Toggle */}
            <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 select-none">
              <input
                type="checkbox"
                checked={settings.noRepeat}
                onChange={e => {
                  playButtonClick(settings.soundVolume);
                  setSettings(prev => ({ ...prev, noRepeat: e.target.checked }));
                }}
                className="w-3.5 h-3.5 accent-amber-500 rounded cursor-pointer"
              />
              <span>Không gọi lại học sinh đã chọn</span>
            </label>

            {/* Progress Count & Bar */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500">
                  Đã gọi:{' '}
                  <strong className="text-amber-700 font-extrabold">
                    {calledCount} / {students.length}
                  </strong>
                </span>

                {calledCount > 0 && (
                  <button
                    onClick={handleResetCalledStatus}
                    className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[11px] font-bold text-amber-700 bg-amber-100 hover:bg-amber-200 transition-colors cursor-pointer"
                    title="Đặt lại lượt gọi"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Đặt lại</span>
                  </button>
                )}
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* 4. STUDENT ROSTER LIST (FLEX-1 SCROLLABLE) */}
          <div className="flex-1 min-h-0 flex flex-col bg-white rounded-xl border border-amber-200/70 p-2 overflow-hidden shadow-2xs">
            <div className="flex items-center justify-between pb-1.5 mb-1 border-b border-slate-100 shrink-0">
              <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1 min-w-0">
                <Users className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span className="truncate">{currentClass.name} ({availableStudents.length} sẵn sàng)</span>
              </span>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => setIsClassManagerOpen(true)}
                  className="text-[11px] font-bold text-sky-600 hover:text-sky-700 hover:underline cursor-pointer"
                  title="Đổi lớp hoặc quản lý các lớp"
                >
                  Đổi lớp
                </button>
                <button
                  onClick={() => setIsStudentManagerOpen(true)}
                  className="text-[11px] font-bold text-amber-600 hover:text-amber-700 hover:underline cursor-pointer"
                >
                  Sửa DS
                </button>
              </div>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto space-y-1 pr-1">
              {students.map(st => {
                const isCalled = calledIds.includes(st.id);
                return (
                  <div
                    key={st.id}
                    className={`flex items-center justify-between px-2 py-1 rounded-lg text-xs transition-colors ${
                      isCalled && settings.noRepeat
                        ? 'bg-slate-100/80 text-slate-400 line-through opacity-60'
                        : 'bg-slate-50 hover:bg-amber-50/70 border border-slate-100 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span
                        className="w-4.5 h-4.5 rounded-full text-[10px] text-white font-black flex items-center justify-center shrink-0 shadow-2xs"
                        style={{ backgroundColor: st.color || '#F59E0B' }}
                      >
                        {st.number}
                      </span>
                      <span className="truncate font-medium">{st.name}</span>
                    </div>

                    {isCalled ? (
                      <span className="text-[10px] text-amber-600 font-semibold flex items-center gap-0.5 shrink-0 ml-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        {st.calledCount ? `${st.calledCount} lần` : 'Đã gọi'}
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400 shrink-0 ml-1">Chờ</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </aside>
      </main>

      {/* ===== MODALS & OVERLAYS ===== */}
      {/* 1. Winner Celebration Modal */}
      <WinnerModal
        winner={selectedStudent}
        isOpen={winnerModalOpen}
        onClose={() => setWinnerModalOpen(false)}
        onSpinAgain={() => {
          setWinnerModalOpen(false);
          setTimeout(() => {
            handleStartSpin();
          }, 200);
        }}
        speechEnabled={settings.speechEnabled}
        onToggleSpeech={() => setSettings(prev => ({ ...prev, speechEnabled: !prev.speechEnabled }))}
        soundEnabled={settings.soundEnabled}
        soundVolume={settings.soundVolume}
        confettiEnabled={settings.confettiEnabled}
        classNameTitle={settings.className}
      />

      {/* 2. Student Management Modal */}
      <StudentManagerModal
        isOpen={isStudentManagerOpen}
        onClose={() => setIsStudentManagerOpen(false)}
        students={students}
        onUpdateStudents={handleUpdateStudents}
        soundVolume={settings.soundVolume}
        classNameTitle={currentClass.name}
      />

      {/* 2b. Class Management Modal */}
      <ClassManagerModal
        isOpen={isClassManagerOpen}
        onClose={() => setIsClassManagerOpen(false)}
        classes={classes}
        activeClassId={activeClassId}
        onSelectClass={handleSelectClass}
        onAddClass={handleAddClass}
        onRenameClass={handleRenameClass}
        onDeleteClass={handleDeleteClass}
        onResetClassCalled={handleResetClassCalled}
        onOpenStudentManagerForClass={classId => {
          handleSelectClass(classId);
          setIsClassManagerOpen(false);
          setIsStudentManagerOpen(true);
        }}
        soundVolume={settings.soundVolume}
      />

      {/* 3. Call History Modal */}
      <CallHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onClearHistory={handleClearHistory}
        onResetCalledStatus={handleResetCalledStatus}
        soundVolume={settings.soundVolume}
      />

      {/* 4. Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={setSettings}
      />

      {/* 5. Game Selector Modal (Kho 14 trò chơi) */}
      <GameSelectorModal
        isOpen={isGameSelectorOpen}
        onClose={() => setIsGameSelectorOpen(false)}
        currentMode={currentMode}
        onSelectMode={setCurrentMode}
        soundVolume={settings.soundVolume}
      />
    </div>
  );
}
