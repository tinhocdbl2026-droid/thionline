@echo off
setlocal
pushd "%~dp0"
if exist ".runtime\node.exe" set "PATH=%CD%\.runtime;%PATH%"
where node >nul 2>nul
if errorlevel 1 goto neednode
node -e "let v=process.versions.node.split('.').map(Number);process.exit(v[0]>22||(v[0]===22&&v[1]>=12)?0:1)"
if errorlevel 1 goto neednode
where npm.cmd >nul 2>nul
if errorlevel 1 goto neednode
if exist ".dependencies-ready" goto run
if exist package-lock.json (call npm ci --no-audit --no-fund) else (call npm install --no-audit --no-fund)
if errorlevel 1 goto failed
echo ready> .dependencies-ready
:run
echo Keep this window open. Press Ctrl+C to stop.
call npm run dev -- --open
if errorlevel 1 goto failed
goto done
:neednode
echo Install Node.js 22.12 or newer from https://nodejs.org/
pause
goto done
:failed
echo Application could not start. See the error above.
pause
:done
popd
endlocal
